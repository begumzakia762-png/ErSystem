# Firebase সেটআপ — একবারই করতে হবে

কোডে Firebase আগে থেকেই বসানো আছে (Complaint Box আর Vacant Positions এখন
Firestore দিয়ে সিঙ্ক হয়)। কিন্তু এটা চালু করতে আপনার নিজের Google
অ্যাকাউন্ট দিয়ে ৪টা ছোট ধাপ করতে হবে — এটা আমি আপনার হয়ে করতে পারি না,
কারণ এটা আপনার নিজের Firebase প্রজেক্ট/অ্যাকাউন্ট লাগে।

**যতক্ষণ এই ধাপগুলো না করছেন, অ্যাপ পুরোপুরি চলবে** — শুধু Complaint Box
আর Vacant Positions সিঙ্ক হবে না (local placeholder data দেখাবে, error
লগে যাবে কিন্তু অ্যাপ crash করবে না)।

## ধাপ ১ — Firebase প্রজেক্ট বানান
1. [console.firebase.google.com](https://console.firebase.google.com) এ যান
2. "Add project" → নাম দিন (যেমন "ABM Corporation")
3. Google Analytics স্কিপ করে দিতে পারেন (দরকার নেই)

## ধাপ ২ — Android অ্যাপ যোগ করুন
1. প্রজেক্টের ভেতরে "Add app" → Android আইকন
2. **Package name** এ ঠিক এটাই দিন: `com.abm.erp`
3. "Register app" চাপুন
4. **google-services.json** ফাইলটা ডাউনলোড করুন
5. এই zip-এর `app/google-services.json` ফাইলটা **এই নতুন ফাইল দিয়ে বদলে দিন** (এখন যেটা আছে সেটা শুধু placeholder, আসল না)

## ধাপ ৩ — Firestore চালু করুন
1. বাম পাশের মেনু থেকে "Firestore Database" → "Create database"
2. "Start in production mode" বেছে নিন (নিচে security rules বসাবো)
3. একটা location বেছে নিন (যেকোনো একটা, যেমন `asia-south1`)

## ধাপ ৪ — Anonymous Authentication চালু করুন
1. বাম পাশের মেনু থেকে "Authentication" → "Get started"
2. "Sign-in method" ট্যাবে "Anonymous" বেছে **Enable** করুন

## ধাপ ৫ — Storage চালু করুন (Chairman's Notice ছবি আপলোডের জন্য)
1. বাম পাশের মেনু থেকে "Storage" → "Get started" (default settings ঠিক আছে)
2. "Rules" ট্যাবে গিয়ে এই zip-এর `storage.rules` ফাইলের কনটেন্ট পেস্ট করে **Publish** করুন

## ধাপ ৬ — Firestore Security Rules বসান
Firestore Database → "Rules" ট্যাবে গিয়ে এই zip-এর `firestore.rules` ফাইলের
কনটেন্ট কপি করে পেস্ট করে **Publish** করুন।

## এরপর
Android Studio-তে `google-services.json` বদলে দেওয়ার পর শুধু **Sync Project
with Gradle Files** করুন, তারপর Run করুন। এখন Complaint Box আর Vacant
Positions সত্যিই সব ফোনের মধ্যে সিঙ্ক হবে।

---
**পরের ধাপে যা যোগ হবে:** Sales/Inventory/Billing/Production ইত্যাদি বাকি
মডিউলগুলোও ধাপে ধাপে এই একই Firestore-এ সরানো হবে (এখন সেগুলো local Room
database-এ আছে, একটা ফোনেই সীমাবদ্ধ)।
