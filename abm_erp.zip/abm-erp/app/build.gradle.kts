plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
    id("com.google.gms.google-services") // reads app/google-services.json — see SETUP_FIREBASE.md
}

android {
    namespace = "com.abm.erp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.abm.erp"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures { compose = true }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Room: on-device database that replaces the in-memory MockRepository.
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // Real GPS location capture (replaces static breadcrumb seed data).
    implementation("com.google.android.gms:play-services-location:21.3.0")
    implementation("com.google.android.gms:play-services-base:18.5.0") // GoogleApiAvailability/ConnectionResult, used by LocationTracker's defensive check
    implementation("androidx.activity:activity-ktx:1.9.0")

    // Real fingerprint/Face unlock for the PIN login screen.
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.fragment:fragment-ktx:1.8.2") // BiometricPrompt needs a FragmentActivity host
    implementation("androidx.appcompat:appcompat:1.7.0") // BiometricPrompt's internal compat dialog (API 26-27) expects an AppCompat-derived theme

    // Firebase: shared multi-device data (Complaint Box, Vacant Positions, and
    // more as each module is ported) plus anonymous Auth so writes are attributable.
    // Requires app/google-services.json from your own Firebase project — see SETUP_FIREBASE.md.
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-firestore-ktx")
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-storage-ktx") // Chairman's Notice image upload

    // Real scannable QR generation for retailer shop tags (SR field data collection)
    implementation("com.google.zxing:core:3.5.3")

    // Loads the Chairman's Notice image from its Firebase Storage download URL
    implementation("io.coil-kt:coil-compose:2.6.0")
}
