package com.abm.erp.ui.market

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary

/**
 * Zone-wise trend, computed from real dealer sales data (not a separate
 * forecast model yet — that needs historical time-series data this
 * prototype doesn't capture). Shows each zone's 90-day sales and how much
 * of it is tied up in due balance, which is the clearest real signal we
 * have today about which zones are healthy vs strained.
 */
@Composable
fun MarketAnalysisScreen() {
    val dealers by MockRepository.dealers.collectAsState()
    val byZone = remember(dealers) {
        dealers.groupBy { it.zone }.mapValues { (_, list) ->
            list.sumOf { it.salesLast90Days } to list.sumOf { it.dueBalance }
        }.toList().sortedByDescending { it.second.first }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Market Analysis", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(4.dp))
        Text("Zone-wise sales vs due balance, from live dealer data.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Spacer(Modifier.height(14.dp))

        if (byZone.isEmpty()) {
            Text("No dealer sales data yet.", color = TextSecondary)
        }
        byZone.forEach { (zone, pair) ->
            val (sales, due) = pair
            val dueRatio = if (sales == 0.0) 0.0 else due / sales
            GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(zone, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text(
                        if (dueRatio < 0.3) "Healthy" else if (dueRatio < 0.6) "Watch" else "At risk",
                        color = if (dueRatio < 0.3) SuccessGreen else if (dueRatio < 0.6) TextSecondary else DangerRed,
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text("90-day sales: ৳${"%,.0f".format(sales)}", style = MaterialTheme.typography.bodyMedium)
                Text("Due balance: ৳${"%,.0f".format(due)} (${"%.0f".format(dueRatio * 100)}% of sales)", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
        }
    }
}
