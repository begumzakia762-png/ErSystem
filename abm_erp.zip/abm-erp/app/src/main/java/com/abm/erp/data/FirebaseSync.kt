package com.abm.erp.data

import android.content.Context
import android.net.Uri
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Thin Firebase layer for the data that genuinely needs to sync across
 * *different people's phones in real time* — an SR's complaint has to reach
 * the Chairman's device, a Chairman's vacancy toggle has to reach every
 * device instantly. That's impossible with the local-only Room database
 * (each phone would only ever see its own copy), which is exactly why this
 * exists.
 *
 * Scope for this pass: Complaint Box + Vacant Positions, because those two
 * screens already exist in Kotlin and are the clearest "must sync across
 * people" cases. Sales/Inventory/Payroll/etc. stay on local Room for now and
 * move here module-by-module in later phases — see the zip's README.
 *
 * IMPORTANT — one-time setup required from you (I can't do this part, it
 * needs your own Google account): create a Firebase project at
 * console.firebase.google.com, register this app (package: com.abm.erp),
 * download google-services.json into the app/ folder, and enable
 * "Anonymous" sign-in + Firestore in the console. Full steps in
 * SETUP_FIREBASE.md at the root of this zip.
 *
 * Until that's done, every call below fails safely into Logcat instead of
 * crashing — so this trial APK still runs perfectly well on local data only.
 */
object FirebaseSync {
    private const val TAG = "FirebaseSync"

    private var initialized = false
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }

    private var complaintsListener: ListenerRegistration? = null
    private var vacancyListener: ListenerRegistration? = null

    private val _complaints = MutableStateFlow<List<ComplaintRecord>>(emptyList())
    val complaints: StateFlow<List<ComplaintRecord>> = _complaints.asStateFlow()

    private val _vacantEmployeeIds = MutableStateFlow<Set<String>>(emptySet())
    val vacantEmployeeIds: StateFlow<Set<String>> = _vacantEmployeeIds.asStateFlow()

    // ================= Dealer Orders =================
    // A dealer places an order on their own phone (DealerHomeScreen); the ASM
    // who covers that dealer's territory approves/rejects it on theirs
    // (DealersScreen). Only Firestore makes that cross-device handoff work.
    private var dealerOrdersListener: ListenerRegistration? = null
    private val _dealerOrders = MutableStateFlow<List<DealerOrderRecord>>(emptyList())
    val dealerOrders: StateFlow<List<DealerOrderRecord>> = _dealerOrders.asStateFlow()

    private fun listenDealerOrders() {
        dealerOrdersListener?.remove()
        dealerOrdersListener = db.collection("dealerOrders")
            .addSnapshotListener { snap, err ->
                if (err != null) { Log.w(TAG, "dealerOrders listener error", err); return@addSnapshotListener }
                _dealerOrders.value = snap?.documents
                    ?.mapNotNull { it.toObject(DealerOrderRecord::class.java) }
                    ?.sortedByDescending { it.createdAtMillis }
                    .orEmpty()
            }
    }

    fun submitDealerOrder(dealerId: String, dealerName: String, product: String, qty: Int) {
        val id = db.collection("dealerOrders").document().id
        val record = DealerOrderRecord(id, dealerId, dealerName, product, qty, "Pending", System.currentTimeMillis())
        db.collection("dealerOrders").document(id).set(record)
            .addOnFailureListener { Log.w(TAG, "submitDealerOrder failed — check Firebase setup", it) }
    }

    fun setDealerOrderStatus(id: String, status: String) {
        db.collection("dealerOrders").document(id).update("status", status)
            .addOnFailureListener { Log.w(TAG, "updating dealer order failed", it) }
    }

    // ================= Chairman's Notice =================
    // A single shared document: whichever image/GIF the Chairman most
    // recently uploaded (to Firebase Storage), everyone sees on login/dashboard.
    private var noticeListener: ListenerRegistration? = null
    private val _chairmanNotice = MutableStateFlow<ChairmanNotice?>(null)
    val chairmanNotice: StateFlow<ChairmanNotice?> = _chairmanNotice.asStateFlow()

    private fun listenChairmanNotice() {
        noticeListener?.remove()
        noticeListener = db.collection("orgState").document("chairmanNotice")
            .addSnapshotListener { snap, err ->
                if (err != null) { Log.w(TAG, "notice listener error", err); return@addSnapshotListener }
                _chairmanNotice.value = snap?.toObject(ChairmanNotice::class.java)
            }
    }

    /** Uploads the image to Firebase Storage, then writes its download URL + caption to Firestore. */
    fun uploadChairmanNotice(localUri: Uri, caption: String) {
        val ref = FirebaseStorage.getInstance().reference
            .child("chairman_notice/${System.currentTimeMillis()}.jpg")
        ref.putFile(localUri)
            .continueWithTask { task ->
                if (!task.isSuccessful) throw task.exception ?: Exception("upload failed")
                ref.downloadUrl
            }
            .addOnSuccessListener { url ->
                db.collection("orgState").document("chairmanNotice")
                    .set(ChairmanNotice(url.toString(), caption, System.currentTimeMillis()))
            }
            .addOnFailureListener { Log.w(TAG, "uploadChairmanNotice failed — check Firebase Storage is enabled in the console", it) }
    }

    fun init(context: Context) {
        try {
            FirebaseApp.initializeApp(context)
            auth.signInAnonymously()
                .addOnSuccessListener {
                    initialized = true
                    listenComplaints()
                    listenVacancy()
                    listenDealerOrders()
                    listenChairmanNotice()
                }
                .addOnFailureListener {
                    Log.w(TAG, "Anonymous sign-in failed — is app/google-services.json in place and Anonymous auth enabled in the Firebase console? Running on local data only until then.", it)
                }
        } catch (e: Exception) {
            Log.w(TAG, "Firebase not configured yet — running on local data only. See SETUP_FIREBASE.md.", e)
        }
    }

    // ================= Complaint Box =================
    private fun listenComplaints() {
        complaintsListener?.remove()
        complaintsListener = db.collection("complaints")
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    Log.w(TAG, "complaints listener error (check Firestore security rules)", err)
                    return@addSnapshotListener
                }
                _complaints.value = snap?.documents
                    ?.mapNotNull { it.toObject(ComplaintRecord::class.java) }
                    ?.sortedByDescending { it.createdAtMillis }
                    .orEmpty()
            }
    }

    fun submitComplaint(fromRole: String, fromName: String, subject: String, message: String, anonymous: Boolean) {
        val id = db.collection("complaints").document().id
        val record = ComplaintRecord(
            id = id,
            fromRole = fromRole,
            fromName = if (anonymous) "Anonymous" else fromName,
            subject = subject,
            message = message,
            anonymous = anonymous,
            resolved = false,
            createdAtMillis = System.currentTimeMillis(),
        )
        db.collection("complaints").document(id).set(record)
            .addOnFailureListener { Log.w(TAG, "submitComplaint failed — is Firebase set up yet? See SETUP_FIREBASE.md.", it) }
    }

    fun setComplaintResolved(id: String, resolved: Boolean) {
        db.collection("complaints").document(id).update("resolved", resolved)
            .addOnFailureListener { Log.w(TAG, "updating complaint failed", it) }
    }

    // ================= Vacant Positions =================
    // Stored as one small document: { ids: [employeeId, ...] }. Simple and
    // cheap to read/write; fine at this scale (a Set of strings).
    private fun listenVacancy() {
        vacancyListener?.remove()
        vacancyListener = db.collection("orgState").document("vacantEmployees")
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    Log.w(TAG, "vacancy listener error (check Firestore security rules)", err)
                    return@addSnapshotListener
                }
                @Suppress("UNCHECKED_CAST")
                val ids = (snap?.get("ids") as? List<String>).orEmpty().toSet()
                _vacantEmployeeIds.value = ids
            }
    }

    fun toggleVacant(employeeId: String) {
        val current = _vacantEmployeeIds.value
        val next = if (employeeId in current) current - employeeId else current + employeeId
        _vacantEmployeeIds.value = next // optimistic UI update; the listener above reconciles once the write lands
        db.collection("orgState").document("vacantEmployees").set(mapOf("ids" to next.toList()))
            .addOnFailureListener {
                Log.w(TAG, "toggleVacant failed — is Firebase set up yet? See SETUP_FIREBASE.md.", it)
                _vacantEmployeeIds.value = current // roll back the optimistic update since the write didn't actually land
            }
    }
}

/**
 * Firestore needs a no-arg constructor to deserialize documents back into
 * this class — Kotlin data classes get one for free as long as every
 * property has a default value, which is why every field below has one.
 */
data class ComplaintRecord(
    val id: String = "",
    val fromRole: String = "",
    val fromName: String = "",
    val subject: String = "",
    val message: String = "",
    val anonymous: Boolean = false,
    val resolved: Boolean = false,
    val createdAtMillis: Long = 0,
)

data class DealerOrderRecord(
    val id: String = "",
    val dealerId: String = "",
    val dealerName: String = "",
    val product: String = "",
    val qty: Int = 0,
    val status: String = "Pending", // Pending | Approved | Rejected
    val createdAtMillis: Long = 0,
)

data class ChairmanNotice(
    val imageUrl: String = "",
    val caption: String = "",
    val uploadedAtMillis: Long = 0,
)
