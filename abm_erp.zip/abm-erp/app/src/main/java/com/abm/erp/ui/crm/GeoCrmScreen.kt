package com.abm.erp.ui.crm

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.abm.erp.core.*
import com.abm.erp.data.CampaignChannel
import com.abm.erp.data.MockRepository
import com.abm.erp.location.LocationTracker
import com.abm.erp.theme.*

@Composable
fun GeoCrmScreen() {
    val routes by MockRepository.routes.collectAsState()
    val campaigns by MockRepository.campaigns.collectAsState()
    var tab by remember { mutableStateOf(0) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Geotagged CRM", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        TabRow(selectedTabIndex = tab, containerColor = androidx.compose.ui.graphics.Color.Transparent, contentColor = ElectricCyan) {
            listOf("Route Audit", "Engagement Hub").forEachIndexed { i, label ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(label) })
            }
        }
        Spacer(Modifier.height(12.dp))

        if (tab == 0) RouteAuditTab(routes) else EngagementHubTab(campaigns)
    }
}

@Composable
private fun LiveGpsTrackingCard() {
    val context = LocalContext.current
    val activity = context as? android.app.Activity
    var tracking by remember { mutableStateOf(false) }
    var pingCount by remember { mutableStateOf(0) }
    var lastSpoofWarning by remember { mutableStateOf(false) }
    var trackingError by remember { mutableStateOf<String?>(null) }

    fun hasFineLocationPermission() =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            tracking = true; trackingError = null
        } else {
            // shouldShowRequestPermissionRationale is false both before the first-ever
            // request AND after a permanent ("Don't ask again") denial — since this
            // callback only fires after a request just happened, false here means
            // permanent denial, which the system permission dialog can't fix a second
            // time; the person has to go to phone Settings directly.
            val permanentlyDenied = activity != null &&
                !ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.ACCESS_FINE_LOCATION)
            trackingError = if (permanentlyDenied)
                "Location permission is permanently denied. Open phone Settings → Apps → ABM ERP → Permissions → Location, allow it, then come back and tap Start."
            else
                "Location permission was denied — tap Start again and allow it to record GPS checkpoints."
        }
    }

    if (tracking && hasFineLocationPermission()) {
        LaunchedEffect(Unit) {
            try {
                LocationTracker(context).liveLocation().collect { fix ->
                    MockRepository.recordGpsPing(MockRepository.currentUser.id, MockRepository.currentUser.name, fix.lat, fix.lng, fix.spoofed)
                    pingCount += 1
                    lastSpoofWarning = fix.spoofed
                }
            } catch (e: Exception) {
                trackingError = e.message ?: "GPS tracking stopped unexpectedly."
                tracking = false
            }
        }
    }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Live GPS tracking", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        Text(
            if (tracking) "Tracking active — $pingCount checkpoint(s) recorded this session"
            else "Tap start to record real device location as breadcrumbs for today's route",
            style = MaterialTheme.typography.bodySmall, color = TextSecondary,
        )
        if (tracking && lastSpoofWarning) {
            Text("⚠ Last fix flagged as a mock/spoofed location", color = DangerRed, style = MaterialTheme.typography.labelSmall)
        }
        trackingError?.let {
            Spacer(Modifier.height(6.dp))
            Text("⚠ $it", color = DangerRed, style = MaterialTheme.typography.labelSmall)
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                trackingError = null
                if (tracking) {
                    tracking = false
                } else if (hasFineLocationPermission()) {
                    tracking = true
                } else {
                    permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = if (tracking) DangerRed else SuccessGreen),
        ) {
            Text(if (tracking) "Stop tracking" else "Start tracking")
        }
    }
}

@Composable
private fun RouteAuditTab(routes: List<com.abm.erp.data.FieldEmployeeRoute>) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { LiveGpsTrackingCard() }
        items(routes) { r ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(r.employeeName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text("${r.date} · ${r.breadcrumbs.size} GPS checkpoints", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(10.dp))
                BreadcrumbTrace(r.breadcrumbs.map { it.lat to it.lng })
                Spacer(Modifier.height(6.dp))
                r.breadcrumbs.forEach { p ->
                    Text(
                        "• ${p.timestamp.toLocalTime()} — (${"%.3f".format(p.lat)}, ${"%.3f".format(p.lng)})" +
                            if (p.spoofed) "  ⚠ spoofed" else "",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (p.spoofed) DangerRed else TextSecondary,
                    )
                }
            }
        }
    }
}

/** Minimal breadcrumb trace renderer: normalizes lat/lng points into a canvas polyline. Swap for a real Maps SDK overlay in production. */
@Composable
private fun BreadcrumbTrace(points: List<Pair<Double, Double>>) {
    if (points.size < 2) return
    val lats = points.map { it.first }
    val lngs = points.map { it.second }
    val minLat = lats.min(); val maxLat = lats.max()
    val minLng = lngs.min(); val maxLng = lngs.max()

    Canvas(modifier = Modifier.fillMaxWidth().height(100.dp)) {
        val path = points.map { (lat, lng) ->
            val nx = if (maxLng == minLng) 0.5f else ((lng - minLng) / (maxLng - minLng)).toFloat()
            val ny = if (maxLat == minLat) 0.5f else 1f - ((lat - minLat) / (maxLat - minLat)).toFloat()
            Offset(nx * size.width, ny * size.height)
        }
        for (i in 0 until path.size - 1) {
            drawLine(ElectricCyan, path[i], path[i + 1], strokeWidth = 4f)
        }
        path.forEach { drawCircle(DeepIndigo, radius = 6f, center = it) }
    }
}

@Composable
private fun EngagementHubTab(campaigns: List<com.abm.erp.data.EngagementCampaign>) {
    var channel by remember { mutableStateOf(CampaignChannel.SMS) }
    var message by remember { mutableStateOf("") }
    var zone by remember { mutableStateOf("Barisal") }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Broadcast promotion / discount alert", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                DualControlDropdown(
                    "Channel",
                    DualControlValue(channel.name, FieldSource.HUMAN),
                    CampaignChannel.values().map { it.name },
                    onManualSelect = { channel = CampaignChannel.valueOf(it) }
                )
                Spacer(Modifier.height(10.dp))
                DualControlTextField(
                    "Message (Bengali robo-call script / SMS / email body)",
                    DualControlValue(message, FieldSource.HUMAN), { message = it }
                )
                Spacer(Modifier.height(10.dp))
                DualControlTextField("Target zone", DualControlValue(zone, FieldSource.HUMAN), { zone = it })
                Spacer(Modifier.height(14.dp))
                ManualSubmitBar("Broadcast now") {
                    if (message.isNotBlank()) {
                        MockRepository.broadcastCampaign(channel, message, zone)
                        message = ""
                    }
                }
            }
        }
        item { Text("Sent campaigns", style = MaterialTheme.typography.titleMedium) }
        items(campaigns.reversed()) { c ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("${c.channel.name} → ${c.targetZone}", fontWeight = FontWeight.SemiBold, color = ElectricCyan)
                Text(c.message, style = MaterialTheme.typography.bodyMedium)
                Text("Delivered to ${c.sentCount} shops", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
