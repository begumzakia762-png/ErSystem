package com.abm.erp.data.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CompanyEntity::class,
        AppUserEntity::class,
        RetailOrderEntity::class,
        DealerEntity::class,
        BulkDealerRequestEntity::class,
        FieldEmployeeRouteEntity::class,
        EngagementCampaignEntity::class,
        AttendanceRecordEntity::class,
        PayrollLineEntity::class,
        VoiceInvoiceEntity::class,
        PaymentProofEntity::class,
        RawMaterialLotEntity::class,
        ProductionBatchEntity::class,
        FactoryAttendanceEntity::class,
        PrescriptionCardEntity::class,
        BoardroomQueryEntity::class,
        ProductEntity::class,
        WarehouseEntity::class,
        StockLevelEntity::class,
        StockMovementEntity::class,
        TaskItemEntity::class,
        ApprovalRequestEntity::class,
        CourierPartnerEntity::class,
        ShipmentEntity::class,
    ],
    version = 4,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun companyDao(): CompanyDao
    abstract fun appUserDao(): AppUserDao
    abstract fun retailOrderDao(): RetailOrderDao
    abstract fun dealerDao(): DealerDao
    abstract fun fieldEmployeeRouteDao(): FieldEmployeeRouteDao
    abstract fun engagementCampaignDao(): EngagementCampaignDao
    abstract fun payrollDao(): PayrollDao
    abstract fun voiceInvoiceDao(): VoiceInvoiceDao
    abstract fun paymentProofDao(): PaymentProofDao
    abstract fun rawMaterialLotDao(): RawMaterialLotDao
    abstract fun productionBatchDao(): ProductionBatchDao
    abstract fun prescriptionCardDao(): PrescriptionCardDao
    abstract fun boardroomQueryDao(): BoardroomQueryDao
    abstract fun productDao(): ProductDao
    abstract fun warehouseDao(): WarehouseDao
    abstract fun stockDao(): StockDao
    abstract fun taskDao(): TaskDao
    abstract fun approvalDao(): ApprovalDao
    abstract fun courierDao(): CourierDao
    abstract fun shipmentDao(): ShipmentDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "abm_erp.db",
                )
                    // Prototype is still under active schema changes; destructive
                    // fallback is fine until the app has real installed users with
                    // data worth preserving across upgrades — switch to real
                    // Migration objects before a production release.
                    .fallbackToDestructiveMigration()
                    .build().also { instance = it }
            }
    }
}
