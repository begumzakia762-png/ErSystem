package com.abm.erp.ui.dealer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.DealerOrderRecord
import com.abm.erp.data.FirebaseSync
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

private val DEALER_PRODUCTS = listOf("ABM Masala Tea 1kg", "ABM Tea Classic 1kg")

@Composable
fun DealerHomeScreen(dealerId: String, onLogout: () -> Unit) {
    val dealer = MockRepository.dealers.collectAsState().value.firstOrNull { it.id == dealerId }
    val allOrders by FirebaseSync.dealerOrders.collectAsState()
    val myOrders = allOrders.filter { it.dealerId == dealerId }.sortedByDescending { it.createdAtMillis }

    var product by remember { mutableStateOf(DEALER_PRODUCTS.first()) }
    var qtyText by remember { mutableStateOf("") }
    var productMenuOpen by remember { mutableStateOf(false) }
    var justSubmitted by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().background(Color(0xFF1E6FA8)).padding(16.dp)) {
            Text("Dealer Portal", color = Color(0xFFE4EEF6), style = MaterialTheme.typography.labelSmall)
            Text(dealer?.name ?: "Dealer", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Text(dealer?.zone ?: "", color = Color(0xFFE4EEF6), style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onLogout) { Text("Logout", color = Color.White) }
        }

        Column(Modifier.fillMaxSize().padding(16.dp)) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Place a new order", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Box {
                    OutlinedButton(onClick = { productMenuOpen = true }, modifier = Modifier.fillMaxWidth()) { Text(product) }
                    DropdownMenu(expanded = productMenuOpen, onDismissRequest = { productMenuOpen = false }) {
                        DEALER_PRODUCTS.forEach { p ->
                            DropdownMenuItem(text = { Text(p) }, onClick = { product = p; productMenuOpen = false })
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Quantity") }, modifier = Modifier.fillMaxWidth())
                if (justSubmitted) {
                    Spacer(Modifier.height(6.dp))
                    Text("✓ Order sent to your Area Manager for approval.", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val qty = qtyText.toIntOrNull() ?: return@Button
                        if (qty <= 0 || dealer == null) return@Button
                        FirebaseSync.submitDealerOrder(dealer.id, dealer.name, product, qty)
                        qtyText = ""
                        justSubmitted = true
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Submit order") }
            }

            Spacer(Modifier.height(16.dp))
            Text("My orders", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            if (myOrders.isEmpty()) {
                Text("No orders placed yet.", color = TextSecondary)
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(myOrders, key = { it.id }) { o -> DealerOrderRow(o) }
            }
        }
    }
}

@Composable
private fun DealerOrderRow(o: DealerOrderRecord) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(o.product, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            val color = when (o.status) { "Approved" -> SuccessGreen; "Rejected" -> DangerRed; else -> WarningAmber }
            Text(o.status, color = color, style = MaterialTheme.typography.labelSmall)
        }
        Text("Qty: ${o.qty}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    }
}
