package com.abm.erp.data.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CompanyDao {
    @Query("SELECT * FROM companies")
    fun getAll(): Flow<List<CompanyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(companies: List<CompanyEntity>)
}

@Dao
interface AppUserDao {
    @Query("SELECT * FROM app_users LIMIT 1")
    fun getCurrent(): Flow<AppUserEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(user: AppUserEntity)
}

@Dao
interface RetailOrderDao {
    @Query("SELECT * FROM retail_orders ORDER BY loggedAtEpochMillis DESC")
    fun getAll(): Flow<List<RetailOrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(order: RetailOrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(orders: List<RetailOrderEntity>)

    @Query("UPDATE retail_orders SET stage = :stage, routedDealerId = COALESCE(:dealerId, routedDealerId) WHERE id = :id")
    suspend fun advance(id: String, stage: String, dealerId: String?)

    @Query("SELECT COUNT(*) FROM retail_orders")
    suspend fun count(): Int
}

@Dao
interface DealerDao {
    @Query("SELECT * FROM dealers")
    fun getAll(): Flow<List<DealerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(dealers: List<DealerEntity>)

    @Query("SELECT COUNT(*) FROM dealers")
    suspend fun count(): Int
}

@Dao
interface FieldEmployeeRouteDao {
    @Query("SELECT * FROM field_employee_routes")
    fun getAll(): Flow<List<FieldEmployeeRouteEntity>>

    @Query("SELECT * FROM field_employee_routes WHERE employeeId = :employeeId AND dateEpochDay = :dateEpochDay LIMIT 1")
    suspend fun getForEmployeeAndDate(employeeId: String, dateEpochDay: Long): FieldEmployeeRouteEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(routes: List<FieldEmployeeRouteEntity>)

    @Query("SELECT COUNT(*) FROM field_employee_routes")
    suspend fun count(): Int
}

@Dao
interface EngagementCampaignDao {
    @Query("SELECT * FROM engagement_campaigns")
    fun getAll(): Flow<List<EngagementCampaignEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(campaign: EngagementCampaignEntity)
}

@Dao
interface PayrollDao {
    @Query("SELECT * FROM payroll_lines")
    fun getAll(): Flow<List<PayrollLineEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(lines: List<PayrollLineEntity>)

    @Query("SELECT COUNT(*) FROM payroll_lines")
    suspend fun count(): Int
}

@Dao
interface VoiceInvoiceDao {
    @Query("SELECT * FROM voice_invoices")
    fun getAll(): Flow<List<VoiceInvoiceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(invoices: List<VoiceInvoiceEntity>)

    @Update
    suspend fun update(invoice: VoiceInvoiceEntity)

    @Query("SELECT COUNT(*) FROM voice_invoices")
    suspend fun count(): Int
}

@Dao
interface PaymentProofDao {
    @Query("SELECT * FROM payment_proofs")
    fun getAll(): Flow<List<PaymentProofEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(payments: List<PaymentProofEntity>)

    @Query("UPDATE payment_proofs SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("SELECT COUNT(*) FROM payment_proofs")
    suspend fun count(): Int
}

@Dao
interface RawMaterialLotDao {
    @Query("SELECT * FROM raw_material_lots")
    fun getAll(): Flow<List<RawMaterialLotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(lots: List<RawMaterialLotEntity>)

    @Query("SELECT COUNT(*) FROM raw_material_lots")
    suspend fun count(): Int
}

@Dao
interface ProductionBatchDao {
    @Query("SELECT * FROM production_batches")
    fun getAll(): Flow<List<ProductionBatchEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(batches: List<ProductionBatchEntity>)

    @Query("UPDATE production_batches SET gatepassReceived = 1 WHERE id = :id")
    suspend fun receiveGatepass(id: String)

    @Query("SELECT COUNT(*) FROM production_batches")
    suspend fun count(): Int
}

@Dao
interface PrescriptionCardDao {
    @Query("SELECT * FROM prescription_cards")
    fun getAll(): Flow<List<PrescriptionCardEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(cards: List<PrescriptionCardEntity>)

    @Query("SELECT COUNT(*) FROM prescription_cards")
    suspend fun count(): Int
}

@Dao
interface BoardroomQueryDao {
    @Query("SELECT * FROM boardroom_queries ORDER BY askedAtEpochMillis ASC")
    fun getAll(): Flow<List<BoardroomQueryEntity>>

    @Insert
    suspend fun insert(query: BoardroomQueryEntity)
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<TaskItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: TaskItemEntity)

    @Query("UPDATE tasks SET done = :done WHERE id = :id")
    suspend fun setDone(id: String, done: Boolean)
}

@Dao
interface ApprovalDao {
    @Query("SELECT * FROM approval_requests ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<ApprovalRequestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(request: ApprovalRequestEntity)

    @Query("UPDATE approval_requests SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("SELECT COUNT(*) FROM approval_requests")
    suspend fun count(): Int
}

@Dao
interface CourierDao {
    @Query("SELECT * FROM courier_partners")
    fun getAll(): Flow<List<CourierPartnerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(couriers: List<CourierPartnerEntity>)

    @Query("SELECT COUNT(*) FROM courier_partners")
    suspend fun count(): Int
}

@Dao
interface ShipmentDao {
    @Query("SELECT * FROM shipments")
    fun getAll(): Flow<List<ShipmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(shipment: ShipmentEntity)

    @Query("UPDATE shipments SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)
}
