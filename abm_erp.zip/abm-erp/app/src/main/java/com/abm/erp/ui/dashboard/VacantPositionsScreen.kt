package com.abm.erp.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.abm.erp.data.EMPLOYEE_DIRECTORY
import com.abm.erp.data.MockRepository
import com.abm.erp.data.UserRole
import com.abm.erp.data.findCoveringEmployee
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

@Composable
fun VacantPositionsScreen(onClose: () -> Unit) {
    val vacantIds by MockRepository.vacantEmployeeIds.collectAsState()
    var query by remember { mutableStateOf("") }

    val visible = remember(query, vacantIds) {
        val q = query.lowercase()
        EMPLOYEE_DIRECTORY.filter { it.role != UserRole.CHAIRMAN }.filter { emp ->
            if (q.isNotBlank()) {
                emp.name.lowercase().contains(q) || emp.role.name.lowercase().contains(q) || emp.geoLabel.lowercase().contains(q)
            } else {
                emp.id in vacantIds // default view: only show already-vacant people, not all 200+
            }
        }.take(100)
    }

    Column(Modifier.padding(16.dp).heightIn(max = 520.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Vacant Positions", style = MaterialTheme.typography.titleMedium)
            IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = "Close") }
        }
        Text(
            "Mark a specific person vacant. Their duties route to whichever filled person above them covers that same area — not the whole tier everywhere, just that person's territory.",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            placeholder = { Text("Search name, role, or district…") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))

        if (visible.isEmpty() && query.isBlank()) {
            Text("No one is currently marked vacant. Search above to find someone.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }

        LazyColumn {
            items(visible, key = { it.id }) { emp ->
                val isVacant = emp.id in vacantIds
                val coveringPerson = if (isVacant) findCoveringEmployee(emp, vacantIds) else null
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(emp.name, style = MaterialTheme.typography.bodyMedium)
                        Text("${emp.role} · ${emp.geoLabel}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        if (isVacant) {
                            Text("Vacant — covered by ${coveringPerson?.name ?: "—"}", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                        } else {
                            Text("Filled", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                        }
                    }
                    Box(
                        modifier = Modifier
                            .size(width = 46.dp, height = 26.dp)
                            .background(if (isVacant) WarningAmber else androidx.compose.ui.graphics.Color(0xFFD8DEE7), CircleShape)
                            .clickable { MockRepository.toggleVacant(emp.id) },
                        contentAlignment = if (isVacant) Alignment.CenterEnd else Alignment.CenterStart,
                    ) {
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 3.dp)
                                .size(20.dp)
                                .background(androidx.compose.ui.graphics.Color.White, CircleShape),
                        )
                    }
                }
            }
        }
    }
}
