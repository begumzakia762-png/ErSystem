package com.abm.erp.ui.courier

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.MockRepository
import com.abm.erp.data.ShipmentStatus
import com.abm.erp.theme.ElectricCyan
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary

@Composable
fun CourierScreen() {
    val couriers by MockRepository.couriers.collectAsState()
    val shipments by MockRepository.shipments.collectAsState()
    var dealerText by remember { mutableStateOf("") }
    var selectedCourier by remember { mutableStateOf<String?>(null) }
    var statusMenuFor by remember { mutableStateOf<String?>(null) }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Courier & Logistics", style = MaterialTheme.typography.headlineSmall) }

        item {
            Text("Courier partners", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            couriers.forEach { c ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(c.name, color = TextPrimary)
                    Text(if (c.hasApi) "API connected" else "Manual (no API)", color = if (c.hasApi) SuccessGreen else TextSecondary, style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        item {
            Spacer(Modifier.height(6.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Book a new shipment", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = dealerText, onValueChange = { dealerText = it }, label = { Text("Dealer / retailer name") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Box {
                    OutlinedButton(onClick = { statusMenuFor = "courier-picker" }, modifier = Modifier.fillMaxWidth()) {
                        Text(couriers.firstOrNull { it.id == selectedCourier }?.name ?: "Choose courier…")
                    }
                    DropdownMenu(expanded = statusMenuFor == "courier-picker", onDismissRequest = { statusMenuFor = null }) {
                        couriers.forEach { c ->
                            DropdownMenuItem(text = { Text(c.name) }, onClick = { selectedCourier = c.id; statusMenuFor = null })
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val courierId = selectedCourier ?: couriers.firstOrNull()?.id ?: return@Button
                        if (dealerText.isBlank()) return@Button
                        MockRepository.bookShipment(courierId, dealerText)
                        dealerText = ""
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Book shipment") }
            }
        }

        item { Spacer(Modifier.height(6.dp)); Text("Shipments", style = MaterialTheme.typography.titleMedium) }
        items(shipments, key = { it.id }) { s ->
            val courier = couriers.firstOrNull { it.id == s.courierId }
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(s.dealerOrRetailer, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Text(s.status.name.replace("_", " "), color = if (s.status == ShipmentStatus.DELIVERED) SuccessGreen else ElectricCyan, style = MaterialTheme.typography.labelSmall)
                }
                Text("${courier?.name ?: s.courierId}${s.trackingId?.let { " · Tracking: $it" } ?: ""}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                Spacer(Modifier.height(8.dp))
                if (courier?.hasApi == true) {
                    Button(onClick = { MockRepository.refreshShipmentStatus(s.id) }) { Text("🔄 Refresh API status") }
                } else {
                    Box {
                        OutlinedButton(onClick = { statusMenuFor = s.id }) { Text("Update status") }
                        DropdownMenu(expanded = statusMenuFor == s.id, onDismissRequest = { statusMenuFor = null }) {
                            ShipmentStatus.values().forEach { st ->
                                DropdownMenuItem(text = { Text(st.name.replace("_", " ")) }, onClick = { MockRepository.setShipmentStatus(s.id, st); statusMenuFor = null })
                            }
                        }
                    }
                }
            }
        }
        item {
            Text(
                "API couriers auto-refresh their stage; traditional couriers without an API are updated by hand by whoever hands off the package.",
                style = MaterialTheme.typography.labelSmall, color = TextSecondary,
            )
        }
    }
}
