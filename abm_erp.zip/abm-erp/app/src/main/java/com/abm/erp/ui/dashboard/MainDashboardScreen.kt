package com.abm.erp.ui.dashboard

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.abm.erp.core.GlassCard
import com.abm.erp.data.*
import com.abm.erp.theme.*

@Composable
fun MainDashboardScreen(onNavigate: (String) -> Unit) {
    val appUser by MockRepository.currentUserFlow.collectAsState()
    val vacantIds by MockRepository.vacantEmployeeIds.collectAsState()

    // Local override so the role-switcher (a testing convenience, same as in
    // the JSX prototype) can preview other designations without logging out.
    var employeeId by remember { mutableStateOf(appUser.employeeId) }
    LaunchedEffect(appUser.employeeId) { employeeId = appUser.employeeId }

    val employee = remember(employeeId) {
        EMPLOYEE_DIRECTORY.firstOrNull { it.id == employeeId }
            ?: EMPLOYEE_DIRECTORY.first { it.role == UserRole.CHAIRMAN }
    }
    val visibleModules = remember(employee.role) { visibleModulesFor(employee.role) }
    val coveredEmployees = remember(employee.id, vacantIds) {
        EMPLOYEE_DIRECTORY.filter { vacantIds.contains(it.id) && findCoveringEmployee(it, vacantIds)?.id == employee.id }
    }

    var showEmployeePicker by remember { mutableStateOf(false) }
    var showVacancyPanel by remember { mutableStateOf(false) }
    var showAccountsPanel by remember { mutableStateOf(false) }
    var toastMessage by remember { mutableStateOf<String?>(null) }
    val chairmanNotice by FirebaseSync.chairmanNotice.collectAsState()
    val noticePickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent(),
    ) { uri -> if (uri != null) FirebaseSync.uploadChairmanNotice(uri, "Company announcement") }

    LaunchedEffect(toastMessage) {
        if (toastMessage != null) {
            kotlinx.coroutines.delay(2200)
            toastMessage = null
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // ---- header: who's logged in + a testing role-switcher ----
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text(employee.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("${roleLabel(employee.role)} · ${employee.geoLabel}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
                TextButton(onClick = { showEmployeePicker = true }) { Text("Switch (test)", color = ElectricCyan) }
            }

            // ---- vacancy-cascade banner: only visible if this person is genuinely covering someone ----
            AnimatedVisibility(visible = coveredEmployees.isNotEmpty()) {
                GlassCard(borderColor = WarningAmber.copy(alpha = 0.6f), modifier = Modifier.fillMaxWidth()) {
                    Text("⚠ Covering: " + coveredEmployees.joinToString("; ") { "${it.name} (${roleLabel(it.role)}, ${it.geoLabel})" },
                        style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = WarningAmber)
                    Spacer(Modifier.height(2.dp))
                    Text("These positions are currently unfilled — their duties temporarily route to you so operations don't stop.",
                        style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }

            // ---- personal target vs achievement ----
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("My target — ${employee.geoLabel}", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                Spacer(Modifier.height(4.dp))
                Text("৳${"%,d".format(employee.achieved)} / ${"%,d".format(employee.target)}",
                    style = MaterialTheme.typography.headlineSmall, color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                val pct = (employee.achieved.toFloat() / employee.target.toFloat()).coerceIn(0f, 1f)
                LinearProgressIndicator(progress = pct, modifier = Modifier.fillMaxWidth().height(6.dp), color = Gold, trackColor = Color(0xFFEEF1F5))
                Spacer(Modifier.height(6.dp))
                Text(employee.insight, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }

            // ---- Chairman's Notice: Chairman uploads, everyone else views read-only ----
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("📢 Chairman's Notice", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    if (employee.role == UserRole.CHAIRMAN) {
                        TextButton(onClick = { noticePickerLauncher.launch("image/*") }) {
                            Text(if (chairmanNotice != null) "Change" else "Upload")
                        }
                    } else if (chairmanNotice != null) {
                        Text("View only", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }
                if (chairmanNotice != null) {
                    Spacer(Modifier.height(8.dp))
                    coil.compose.AsyncImage(
                        model = chairmanNotice!!.imageUrl,
                        contentDescription = chairmanNotice!!.caption,
                        modifier = Modifier.fillMaxWidth().height(160.dp),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(chairmanNotice!!.caption, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                } else {
                    Text(
                        if (employee.role == UserRole.CHAIRMAN) "No announcement posted yet — tap Upload to add a PNG or GIF everyone will see."
                        else "No announcement from the Chairman right now.",
                        style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                    )
                }
            }

            // ---- categorized module grid ----
            CATEGORY_ORDER.forEach { category ->
                val itemsInCategory = visibleModules.filter { it.category == category }
                if (itemsInCategory.isNotEmpty()) {
                    Text(category.uppercase(), style = MaterialTheme.typography.labelMedium, color = TextSecondary, fontWeight = FontWeight.Bold)
                    itemsInCategory.chunked(3).forEach { rowItems ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            rowItems.forEach { module ->
                                ModuleTile(
                                    module = module,
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        val route = IMPLEMENTED_MODULE_ROUTES[module.key]
                                        if (route != null) onNavigate(route)
                                        else toastMessage = "${module.label} — coming in the next update"
                                    },
                                )
                            }
                            // pad the last row so tiles stay a consistent width
                            repeat(3 - rowItems.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }

            if (employee.role == UserRole.CHAIRMAN) {
                OutlinedButton(onClick = { showVacancyPanel = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("🪑 Vacant Positions")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { showAccountsPanel = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("🔑 Account & Access Control")
                }
            }

            Spacer(Modifier.height(24.dp))
        }

        AnimatedVisibility(visible = toastMessage != null, modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp)) {
            Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFF1B2430)) {
                Text(toastMessage ?: "", color = Color.White, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), style = MaterialTheme.typography.bodySmall)
            }
        }
    }

    if (showEmployeePicker) {
        EmployeePickerDialog(
            currentId = employeeId,
            onPick = { employeeId = it; showEmployeePicker = false },
            onDismiss = { showEmployeePicker = false },
        )
    }
    if (showVacancyPanel) {
        Dialog(onDismissRequest = { showVacancyPanel = false }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                VacantPositionsScreen(onClose = { showVacancyPanel = false })
            }
        }
    }
    if (showAccountsPanel) {
        Dialog(onDismissRequest = { showAccountsPanel = false }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                AccountsScreen(onClose = { showAccountsPanel = false })
            }
        }
    }
}

@Composable
private fun ModuleTile(module: AppModule, modifier: Modifier = Modifier, onClick: () -> Unit) {
    GlassCard(modifier = modifier.height(72.dp).clickable(onClick = onClick)) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(module.label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun EmployeePickerDialog(currentId: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(query) {
        val q = query.lowercase()
        if (q.isBlank()) EMPLOYEE_DIRECTORY.take(60)
        else EMPLOYEE_DIRECTORY.filter {
            it.name.lowercase().contains(q) || it.role.name.lowercase().contains(q) || it.geoLabel.lowercase().contains(q)
        }.take(60)
    }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp).heightIn(max = 480.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Switch employee (testing)", style = MaterialTheme.typography.titleMedium)
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = "Close") }
                }
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("Search name, role, or district…") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                )
                LazyColumn {
                    items(filtered, key = { it.id }) { emp ->
                        val selected = emp.id == currentId
                        Text(
                            "${emp.name}  ·  ${roleLabel(emp.role)}  ·  ${emp.geoLabel}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (selected) ElectricCyan else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPick(emp.id) }
                                .padding(vertical = 10.dp),
                        )
                    }
                }
            }
        }
    }
}

/** Human-friendly designation label (UserRole enum names are already short/clear, but centralizing here in case that changes). */
fun roleLabel(role: UserRole): String = role.name
