package com.abm.erp.theme

import androidx.compose.ui.graphics.Color

// Midnight Obsidian palette
val ObsidianBg = Color(0xFF05070B)
val ObsidianBgAlt = Color(0xFF0A0E17)
val ElectricCyan = Color(0xFF0EA5E9)
val DeepIndigo = Color(0xFF4338CA)
val GlassSurface = Color(0x1AFFFFFF)      // translucent white for glass cards
val GlassBorder = Color(0x330EA5E9)       // faint cyan border
val TextPrimary = Color(0xFFE6EDF7)
val TextSecondary = Color(0xFF8B94A7)
val SuccessGreen = Color(0xFF22C55E)
val WarningAmber = Color(0xFFF59E0B)
val DangerRed = Color(0xFFEF4444)
val RiskGreen = Color(0xFF22C55E)
val RiskYellow = Color(0xFFF59E0B)
val RiskRed = Color(0xFFEF4444)

// ABM Corporation brand palette (from the design-review phase) — used by
// LoginScreen and the dashboard header/top bar. Kept alongside the older
// Obsidian palette since inner module screens still use cyan-accented charts.
val SkyTop = Color(0xFF1E6FA8)
val Sky = Color(0xFF2E8BC9)
val SkyHorizon = Color(0xFF8FD0E8)
val Gold = Color(0xFFD4AF6A)
val GoldBright = Color(0xFFF3D998)
val GoldDeep = Color(0xFF8A6A30)
