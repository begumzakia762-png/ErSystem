package com.abm.erp.data.room

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room table definitions. These are the on-disk, flat/serializable counterparts
 * of the rich domain models in data/Models.kt. AppRepository maps between the
 * two directions so every UI Composable keeps working against the same
 * domain types (RetailOrder, Dealer, etc.) it always did.
 *
 * Complex nested fields (lists of value objects) are stored as compact
 * delimited strings via the *Raw fields and packed/unpacked in Converters.kt,
 * to avoid pulling in a JSON library for this first persistence pass.
 */

@Entity(tableName = "companies")
data class CompanyEntity(@PrimaryKey val id: String, val name: String)

@Entity(tableName = "app_users")
data class AppUserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val role: String,
    val companyId: String,
    val zone: String,
)

@Entity(tableName = "retail_orders")
data class RetailOrderEntity(
    @PrimaryKey val id: String,
    val retailerName: String,
    val loggedBySoId: String,
    val zone: String,
    val items: String,
    val amount: Double,
    val stage: String,
    val routedDealerId: String?,
    val loggedAtEpochMillis: Long,
    val retailerPhotoUri: String? = null,
    val retailerLat: Double? = null,
    val retailerLng: Double? = null,
    val retailerQrCode: String? = null,
)

@Entity(tableName = "dealers")
data class DealerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val zone: String,
    val dueBalance: Double,
    val salesLast90Days: Double,
)

@Entity(tableName = "bulk_dealer_requests")
data class BulkDealerRequestEntity(
    @PrimaryKey val id: String,
    val dealerId: String,
    val requestedByAsmId: String,
    val items: String,
    val warehouseAvailable: Boolean,
)

@Entity(tableName = "field_employee_routes", primaryKeys = ["employeeId", "dateEpochDay"])
data class FieldEmployeeRouteEntity(
    val employeeId: String,
    val employeeName: String,
    val dateEpochDay: Long,
    val breadcrumbsRaw: String, // packed GpsPing list, see Converters.packBreadcrumbs
)

@Entity(tableName = "engagement_campaigns")
data class EngagementCampaignEntity(
    @PrimaryKey val id: String,
    val channel: String,
    val message: String,
    val targetZone: String,
    val sentCount: Int,
)

@Entity(tableName = "attendance_records")
data class AttendanceRecordEntity(
    @PrimaryKey(autoGenerate = true) val rowId: Long = 0,
    val employeeId: String,
    val dateEpochDay: Long,
    val checkedIn: Boolean,
    val gpsValid: Boolean,
)

@Entity(tableName = "payroll_lines")
data class PayrollLineEntity(
    @PrimaryKey val employeeId: String,
    val employeeName: String,
    val basePay: Double,
    val targetAmount: Double,
    val achievedAmount: Double,
    val commissionRate: Double,
    val unapprovedAbsenceDays: Int,
    val dailyWage: Double,
)

@Entity(tableName = "voice_invoices")
data class VoiceInvoiceEntity(
    @PrimaryKey val id: String,
    val dealerId: String,
    val itemsRaw: String, // packed InvoiceLineItem list, see Converters.packInvoiceItems
    val previousDue: Double,
)

@Entity(tableName = "payment_proofs")
data class PaymentProofEntity(
    @PrimaryKey val id: String,
    val dealerId: String,
    val amount: Double,
    val proofRef: String,
    val status: String,
)

@Entity(tableName = "raw_material_lots")
data class RawMaterialLotEntity(
    @PrimaryKey val id: String,
    val materialName: String,
    val qtyKg: Double,
    val costPerKg: Double,
    val purchasedOnEpochDay: Long,
)

@Entity(tableName = "production_batches")
data class ProductionBatchEntity(
    @PrimaryKey val id: String,
    val cycleType: String,
    val inputKg: Double,
    val outputKg: Double,
    val gatepassReceived: Boolean,
)

@Entity(tableName = "factory_attendance")
data class FactoryAttendanceEntity(
    @PrimaryKey(autoGenerate = true) val rowId: Long = 0,
    val laborerId: String,
    val dateEpochDay: Long,
    val withinFactoryGeofence: Boolean,
    val wifiIpLocked: Boolean,
)

@Entity(tableName = "prescription_cards")
data class PrescriptionCardEntity(
    @PrimaryKey val id: String,
    val title: String,
    val body: String,
    val severity: String,
)

@Entity(tableName = "boardroom_queries")
data class BoardroomQueryEntity(
    @PrimaryKey(autoGenerate = true) val rowId: Long = 0,
    val question: String,
    val answer: String,
    val askedAtEpochMillis: Long,
)

@Entity(tableName = "tasks")
data class TaskItemEntity(
    @PrimaryKey val id: String,
    val title: String,
    val assignee: String,
    val done: Boolean,
    val createdAtEpochMillis: Long,
)

@Entity(tableName = "approval_requests")
data class ApprovalRequestEntity(
    @PrimaryKey val id: String,
    val type: String,
    val fromEmployee: String,
    val detail: String,
    val status: String,
    val createdAtEpochMillis: Long,
)

@Entity(tableName = "courier_partners")
data class CourierPartnerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val hasApi: Boolean,
)

@Entity(tableName = "shipments")
data class ShipmentEntity(
    @PrimaryKey val id: String,
    val courierId: String,
    val dealerOrRetailer: String,
    val trackingId: String?,
    val status: String,
)
