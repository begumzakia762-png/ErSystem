package com.abm.erp

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.abm.erp.data.MockRepository
import com.abm.erp.nav.Dest
import com.abm.erp.nav.ABMNavGraph
import com.abm.erp.nav.bottomNavItems
import com.abm.erp.theme.ElectricCyan
import com.abm.erp.theme.ABMErpTheme
import com.abm.erp.theme.TextSecondary
import com.abm.erp.ui.login.LoginScreen

/**
 * FragmentActivity (not plain ComponentActivity) because androidx.biometric's
 * BiometricPrompt requires a FragmentActivity host to attach its dialog to.
 * FragmentActivity is itself a ComponentActivity, so setContent{} below still
 * works exactly the same way.
 */
class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ABMErpTheme {
                var mode by remember { mutableStateOf("login") } // "login" | "staff" | "dealerLogin" | "dealer"
                var activeDealerId by remember { mutableStateOf<String?>(null) }

                when (mode) {
                    "staff" -> ABMApp()
                    "dealerLogin" -> com.abm.erp.ui.dealer.DealerLoginScreen(
                        onDealerChosen = { id -> activeDealerId = id; mode = "dealer" },
                        onBackToStaffLogin = { mode = "login" },
                    )
                    "dealer" -> com.abm.erp.ui.dealer.DealerHomeScreen(
                        dealerId = activeDealerId ?: "",
                        onLogout = { mode = "login" },
                    )
                    else -> LoginScreen(
                        activity = this,
                        onLoginSuccess = { mode = "staff" },
                        onDealerLoginRequested = { mode = "dealerLogin" },
                    )
                }
            }
        }
    }
}

private val destIcons = mapOf(
    Dest.Dashboard.route to Icons.Filled.Dashboard,
    Dest.Sales.route to Icons.Filled.PointOfSale,
    Dest.Inventory.route to Icons.Filled.Inventory2,
    Dest.Crm.route to Icons.Filled.Map,
    Dest.Hrm.route to Icons.Filled.Groups,
    Dest.Billing.route to Icons.Filled.ReceiptLong,
    Dest.Production.route to Icons.Filled.Factory,
    Dest.Boardroom.route to Icons.Filled.Insights, // "Master Advisory" boardroom slot
)

@Composable
fun ABMApp() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: Dest.Dashboard.route
    val currentUser by MockRepository.currentUserFlow.collectAsState()

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(
                                    brush = Brush.linearGradient(listOf(com.abm.erp.theme.GoldBright, com.abm.erp.theme.Gold, com.abm.erp.theme.GoldDeep)),
                                    shape = CircleShape,
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text("ABM", color = Color(0xFF241A08), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(currentUser.name, style = MaterialTheme.typography.titleSmall)
                            Text("${currentUser.role} · ${currentUser.zone}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0A0E17)) {
                bottomNavItems.forEach { dest ->
                    val selected = currentRoute == dest.route
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            if (!selected) navController.navigate(dest.route) {
                                popUpTo(Dest.Dashboard.route)
                                launchSingleTop = true
                            }
                        },
                        icon = { Icon(destIcons[dest.route]!!, contentDescription = dest.label) },
                        label = { Text(dest.label, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ElectricCyan,
                            selectedTextColor = ElectricCyan,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary,
                            indicatorColor = ElectricCyan.copy(alpha = 0.15f),
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            ABMNavGraph(navController = navController)
        }
    }
}
