package com.abm.erp.data

import android.content.Context
import androidx.room.withTransaction
import com.abm.erp.data.room.AppDatabase
import com.abm.erp.data.room.ProductEntity
import com.abm.erp.data.room.StockLevelEntity
import com.abm.erp.data.room.StockMovementEntity
import com.abm.erp.data.room.WarehouseEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset

/**
 * Inventory / Stock Management module. Kept as its own repository object
 * (rather than folded into MockRepository) so modules stay decoupled as the
 * app grows — Sales/Dealer/Production screens will read stock levels from
 * here directly once they're wired up (Phase 3+).
 *
 * Call InventoryRepository.init(context) once, from ABMApplication.onCreate.
 */
object InventoryRepository {

    private lateinit var db: AppDatabase
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun init(context: Context) {
        if (::db.isInitialized) return
        db = AppDatabase.getInstance(context)
        seedIfEmpty()
        wireFlows()
    }

    lateinit var products: StateFlow<List<Product>>
        private set

    lateinit var warehouses: StateFlow<List<Warehouse>>
        private set

    lateinit var stockLevels: StateFlow<List<StockLevelView>>
        private set

    lateinit var movements: StateFlow<List<StockMovement>>
        private set

    val lowStockCount: Int get() = stockLevels.value.count { it.isLowStock }

    fun addProduct(sku: String, name: String, unit: String, category: String, reorderThreshold: Double, defaultUnitPrice: Double) {
        scope.launch {
            db.productDao().upsert(
                ProductEntity(
                    id = "PRD-${System.currentTimeMillis()}",
                    sku = sku, name = name, unit = unit, category = category,
                    reorderThreshold = reorderThreshold, defaultUnitPrice = defaultUnitPrice,
                )
            )
        }
    }

    fun addWarehouse(name: String, zone: String, stockCategory: StockCategory = StockCategory.STORE) {
        scope.launch {
            db.warehouseDao().upsert(WarehouseEntity(id = "WH-${System.currentTimeMillis()}", name = name, zone = zone, stockCategory = stockCategory.name))
        }
    }

    /** Adds stock (e.g. purchase, production output). Always succeeds. */
    fun stockIn(productId: String, warehouseId: String, quantity: Double, reason: String) {
        scope.launch { adjustStock(productId, warehouseId, quantity, MovementType.IN, reason) }
    }

    /**
     * Removes stock (e.g. dealer fulfillment, damage). Suspends the caller so the
     * UI can react to whether it actually happened — returns false instead of
     * going negative if there isn't enough on hand.
     */
    suspend fun stockOut(productId: String, warehouseId: String, quantity: Double, reason: String): Boolean {
        val current = db.stockDao().getLevel(productId, warehouseId)?.quantityOnHand ?: 0.0
        if (current < quantity) return false
        adjustStock(productId, warehouseId, quantity, MovementType.OUT, reason)
        return true
    }

    private suspend fun adjustStock(productId: String, warehouseId: String, quantity: Double, type: MovementType, reason: String) {
        db.withTransaction {
            val current = db.stockDao().getLevel(productId, warehouseId)?.quantityOnHand ?: 0.0
            val updated = when (type) {
                MovementType.IN -> current + quantity
                MovementType.OUT -> current - quantity
                MovementType.ADJUST -> quantity
            }
            db.stockDao().upsertLevel(StockLevelEntity(productId, warehouseId, updated))
            db.stockDao().insertMovement(
                StockMovementEntity(
                    productId = productId, warehouseId = warehouseId, type = type.name,
                    quantity = quantity, reason = reason, timestampEpochMillis = System.currentTimeMillis(),
                )
            )
        }
    }

    // ================= internal wiring =================

    private fun wireFlows() {
        products = db.productDao().getAll().map { it.toDomain() }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        warehouses = db.warehouseDao().getAll().map { it.toDomain() }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        stockLevels = combine(
            db.productDao().getAll(), db.warehouseDao().getAll(), db.stockDao().getAllLevels(),
        ) { productEntities, warehouseEntities, levelEntities ->
            val productsById = productEntities.associateBy { it.id }
            val warehousesById = warehouseEntities.associateBy { it.id }
            levelEntities.mapNotNull { level ->
                val product = productsById[level.productId] ?: return@mapNotNull null
                val warehouse = warehousesById[level.warehouseId] ?: return@mapNotNull null
                StockLevelView(
                    productId = product.id, productName = product.name, unit = product.unit,
                    warehouseId = warehouse.id, warehouseName = warehouse.name,
                    quantityOnHand = level.quantityOnHand, reorderThreshold = product.reorderThreshold,
                    stockCategory = StockCategory.valueOf(warehouse.stockCategory),
                )
            }.sortedBy { it.productName }
        }.stateIn(scope, SharingStarted.Eagerly, emptyList())

        movements = combine(
            db.productDao().getAll(), db.warehouseDao().getAll(), db.stockDao().getAllMovements(),
        ) { productEntities, warehouseEntities, movementEntities ->
            val productsById = productEntities.associateBy { it.id }
            val warehousesById = warehouseEntities.associateBy { it.id }
            movementEntities.mapNotNull { m ->
                val product = productsById[m.productId] ?: return@mapNotNull null
                val warehouse = warehousesById[m.warehouseId] ?: return@mapNotNull null
                StockMovement(
                    id = m.id, productId = product.id, productName = product.name,
                    warehouseId = warehouse.id, warehouseName = warehouse.name,
                    type = MovementType.valueOf(m.type), quantity = m.quantity, reason = m.reason,
                    timestamp = LocalDateTime.ofInstant(Instant.ofEpochMilli(m.timestampEpochMillis), ZoneOffset.UTC),
                )
            }
        }.stateIn(scope, SharingStarted.Eagerly, emptyList())
    }

    /** Starter products/warehouses/stock so the screen isn't empty on first run. */
    private fun seedIfEmpty() = runBlocking(Dispatchers.IO) {
        if (db.warehouseDao().count() == 0) {
            db.warehouseDao().upsertAll(
                listOf(
                    WarehouseEntity("WH-1", "Barisal Main Warehouse", "Barisal", StockCategory.STORE.name),
                    WarehouseEntity("WH-2", "Khulna Depot", "Khulna", StockCategory.STORE.name),
                    WarehouseEntity("WH-3", "Rajshahi Depot", "Rajshahi", StockCategory.STORE.name),
                    WarehouseEntity("WH-4", "Factory Production Store", "Barisal", StockCategory.PRODUCTION.name),
                )
            )
        }
        if (db.productDao().count() == 0) {
            db.productDao().upsertAll(
                listOf(
                    ProductEntity("PRD-1", "MHN-MASALA-1KG", "ABM Masala Tea 1kg", "kg", "Tea", 50.0, 420.0),
                    ProductEntity("PRD-2", "MHN-CLASSIC-1KG", "ABM Tea Classic 1kg", "kg", "Tea", 40.0, 380.0),
                )
            )
        }
        // Seed opening stock only once, guarded by absence of a stock level row.
        if (db.stockDao().getLevel("PRD-1", "WH-1") == null) {
            adjustStock("PRD-1", "WH-1", 320.0, MovementType.IN, "Opening stock")
            adjustStock("PRD-2", "WH-1", 45.0, MovementType.IN, "Opening stock")
            adjustStock("PRD-1", "WH-2", 180.0, MovementType.IN, "Opening stock")
            adjustStock("PRD-1", "WH-4", 600.0, MovementType.IN, "Raw material received")
            adjustStock("PRD-2", "WH-4", 150.0, MovementType.IN, "Raw material received")
        }
    }
}

private fun ProductEntity.toDomainSingle() = Product(id, sku, name, unit, category, reorderThreshold, defaultUnitPrice)
private fun List<ProductEntity>.toDomain() = map { it.toDomainSingle() }

private fun WarehouseEntity.toDomainSingle() = Warehouse(id, name, zone, StockCategory.valueOf(stockCategory))
private fun List<WarehouseEntity>.toDomain() = map { it.toDomainSingle() }
