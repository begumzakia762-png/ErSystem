package com.abm.erp.ui.complaint

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.ComplaintRecord
import com.abm.erp.data.FirebaseSync
import com.abm.erp.data.MockRepository
import com.abm.erp.data.UserRole
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextSecondary

/** Backed by Firestore (via FirebaseSync) — a complaint submitted on an SR's
 *  phone has to reach the Chairman's phone, which a local-only list can
 *  never do. Falls back to an empty inbox if Firebase isn't set up yet
 *  (see SETUP_FIREBASE.md); submitting still works locally-optimistically. */
@Composable
fun ComplaintBoxScreen() {
    val appUser by MockRepository.currentUserFlow.collectAsState()
    val isChairman = appUser.role == UserRole.CHAIRMAN
    val complaints by FirebaseSync.complaints.collectAsState()

    var subject by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var anonymous by remember { mutableStateOf(false) }
    var submitted by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(if (isChairman) "Complaint Box — Inbox" else "Complaint Box", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(4.dp))
        Text(
            if (isChairman) "From all designations, SR to MD." else "Goes straight to the Chairman. Only they can read it — not your manager, not anyone else.",
            style = MaterialTheme.typography.bodySmall, color = TextSecondary,
        )
        Spacer(Modifier.height(12.dp))

        if (isChairman) {
            if (complaints.isEmpty()) {
                Text("No complaints submitted yet.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(complaints, key = { it.id }) { c ->
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(c.subject, style = MaterialTheme.typography.bodyMedium)
                            Text(if (c.resolved) "Resolved" else "Open", color = if (c.resolved) SuccessGreen else DangerRed, style = MaterialTheme.typography.labelSmall)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(c.message, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            (if (c.anonymous) "Anonymous" else c.fromName) + " · " + c.fromRole,
                            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                        )
                        Spacer(Modifier.height(6.dp))
                        TextButton(onClick = { FirebaseSync.setComplaintResolved(c.id, !c.resolved) }) {
                            Text(if (c.resolved) "Mark Open" else "Mark Resolved")
                        }
                    }
                }
            }
        } else {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(value = subject, onValueChange = { subject = it }, label = { Text("Subject") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = message, onValueChange = { message = it }, label = { Text("Describe your complaint or request…") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Checkbox(checked = anonymous, onCheckedChange = { anonymous = it })
                    Text("Send anonymously (Chairman won't see your name)", style = MaterialTheme.typography.labelSmall)
                }
                if (submitted) {
                    Text("✓ Sent to the Chairman.", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (subject.isBlank() || message.isBlank()) return@Button
                        FirebaseSync.submitComplaint(appUser.role.name, appUser.name, subject, message, anonymous)
                        subject = ""; message = ""; anonymous = false
                        submitted = true
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Submit to Chairman") }
            }
        }
    }
}
