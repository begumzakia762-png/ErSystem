package com.abm.erp.data.room

import com.abm.erp.data.GpsPing
import com.abm.erp.data.InvoiceLineItem
import java.time.LocalDateTime
import java.time.ZoneOffset

/**
 * Manual pack/unpack for the two nested value-object lists in the domain
 * model (FieldEmployeeRoute.breadcrumbs, VoiceInvoice.items). Kept as plain
 * delimited strings (no JSON dependency) to keep this first persistence pass
 * dependency-light. Field separator "|", record separator ";".
 */
object Converters {

    // ---- GpsPing list <-> String ----
    // record: lat,lng,epochMillis,spoofed
    fun packBreadcrumbs(pings: List<GpsPing>): String =
        pings.joinToString(";") { p ->
            val epochMillis = p.timestamp.toInstant(ZoneOffset.UTC).toEpochMilli()
            "${p.lat},${p.lng},$epochMillis,${p.spoofed}"
        }

    fun unpackBreadcrumbs(raw: String): List<GpsPing> {
        if (raw.isBlank()) return emptyList()
        return raw.split(";").filter { it.isNotBlank() }.map { record ->
            val (lat, lng, epochMillis, spoofed) = record.split(",")
            GpsPing(
                lat = lat.toDouble(),
                lng = lng.toDouble(),
                timestamp = LocalDateTime.ofInstant(
                    java.time.Instant.ofEpochMilli(epochMillis.toLong()), ZoneOffset.UTC
                ),
                spoofed = spoofed.toBoolean(),
            )
        }
    }

    // ---- InvoiceLineItem list <-> String ----
    // record: name,qty,unit,unitPrice,discountPct  (name must not contain "," or ";")
    fun packInvoiceItems(items: List<InvoiceLineItem>): String =
        items.joinToString(";") { i ->
            val safeName = i.name.replace(",", "").replace(";", "")
            "$safeName,${i.qty},${i.unit},${i.unitPrice},${i.discountPct}"
        }

    fun unpackInvoiceItems(raw: String): MutableList<InvoiceLineItem> {
        if (raw.isBlank()) return mutableListOf()
        return raw.split(";").filter { it.isNotBlank() }.map { record ->
            val parts = record.split(",")
            val name = parts[0]
            val qty = parts[1].toDouble()
            val unit = parts[2]
            val unitPrice = parts[3].toDouble()
            val discountPct = parts[4].toDouble()
            InvoiceLineItem(name, qty, unit, unitPrice, discountPct)
        }.toMutableList()
    }
}
