package com.abm.erp.ui.inventory

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.InventoryRepository
import com.abm.erp.data.MovementType
import com.abm.erp.theme.*
import kotlinx.coroutines.launch

@Composable
fun InventoryScreen() {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Inventory & Stock Management", style = MaterialTheme.typography.headlineSmall)
        Text("Real-time stock across warehouses", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        TabRow(selectedTabIndex = tab, containerColor = Color.Transparent, contentColor = ElectricCyan) {
            listOf("Stock Levels", "Stock In/Out", "Add Product").forEachIndexed { i, label ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(label) })
            }
        }
        Spacer(Modifier.height(12.dp))
        when (tab) {
            0 -> StockLevelsTab()
            1 -> StockMovementTab()
            else -> AddProductTab()
        }
    }
}

@Composable
private fun StockLevelsTab() {
    val levels by InventoryRepository.stockLevels.collectAsState()
    var category by remember { mutableStateOf(com.abm.erp.data.StockCategory.STORE) }
    val filtered = levels.filter { it.stockCategory == category }
    val lowCount = filtered.count { it.isLowStock }

    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            com.abm.erp.data.StockCategory.values().forEach { c ->
                FilterChip(
                    selected = category == c,
                    onClick = { category = c },
                    label = { Text(if (c == com.abm.erp.data.StockCategory.STORE) "Store" else "Production") },
                    modifier = Modifier.weight(1f),
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (lowCount > 0) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text("⚠ $lowCount item(s) at or below reorder level", color = WarningAmber, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            items(filtered) { level ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(level.productName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text(level.warehouseName, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("${"%.1f".format(level.quantityOnHand)} ${level.unit}", color = if (level.isLowStock) DangerRed else SuccessGreen, fontWeight = FontWeight.Bold)
                            if (level.isLowStock) {
                                Text("below reorder (${"%.0f".format(level.reorderThreshold)})", style = MaterialTheme.typography.labelSmall, color = DangerRed)
                            }
                        }
                    }
                }
            }
            if (filtered.isEmpty()) {
                item { Text("No stock recorded yet in this category.", color = TextSecondary) }
            }
        }
    }
}

@Composable
private fun StockMovementTab() {
    val products by InventoryRepository.products.collectAsState()
    val warehouses by InventoryRepository.warehouses.collectAsState()
    val movements by InventoryRepository.movements.collectAsState()
    val scope = rememberCoroutineScope()

    var selectedProduct by remember { mutableStateOf<String?>(null) }
    var selectedWarehouse by remember { mutableStateOf<String?>(null) }
    var qtyText by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Record stock movement", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))

                Text("Product", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                DropdownPicker(
                    options = products.map { it.id to it.name },
                    selectedId = selectedProduct,
                    onSelect = { selectedProduct = it },
                )
                Spacer(Modifier.height(8.dp))

                Text("Warehouse", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                DropdownPicker(
                    options = warehouses.map { it.id to it.name },
                    selectedId = selectedWarehouse,
                    onSelect = { selectedWarehouse = it },
                )
                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = qtyText, onValueChange = { qtyText = it },
                    label = { Text("Quantity") }, modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = reason, onValueChange = { reason = it },
                    label = { Text("Reason (e.g. Dealer fulfillment, Purchase)") }, modifier = Modifier.fillMaxWidth(),
                )
                errorMsg?.let {
                    Spacer(Modifier.height(4.dp))
                    Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val qty = qtyText.toDoubleOrNull()
                            if (selectedProduct == null || selectedWarehouse == null || qty == null || qty <= 0.0) {
                                errorMsg = "Select product, warehouse, and a valid quantity."
                                return@Button
                            }
                            errorMsg = null
                            InventoryRepository.stockIn(selectedProduct!!, selectedWarehouse!!, qty, reason.ifBlank { "Stock in" })
                            qtyText = ""; reason = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                    ) { Text("Stock IN") }

                    Button(
                        onClick = {
                            val qty = qtyText.toDoubleOrNull()
                            if (selectedProduct == null || selectedWarehouse == null || qty == null || qty <= 0.0) {
                                errorMsg = "Select product, warehouse, and a valid quantity."
                                return@Button
                            }
                            scope.launch {
                                val ok = InventoryRepository.stockOut(selectedProduct!!, selectedWarehouse!!, qty, reason.ifBlank { "Stock out" })
                                errorMsg = if (ok) null else "Not enough stock on hand for this warehouse."
                                if (ok) { qtyText = ""; reason = "" }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                    ) { Text("Stock OUT") }
                }
            }
        }
        item { Text("Movement history", style = MaterialTheme.typography.titleMedium) }
        items(movements) { m ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("${m.productName} · ${m.warehouseName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text(m.reason, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    Text(
                        "${if (m.type == MovementType.IN) "+" else "−"}${"%.1f".format(m.quantity)}",
                        color = if (m.type == MovementType.IN) SuccessGreen else DangerRed,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}

@Composable
private fun AddProductTab() {
    var sku by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var reorder by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Add a new product / SKU", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = sku, onValueChange = { sku = it }, label = { Text("SKU code") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Product name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = unit, onValueChange = { unit = it }, label = { Text("Unit (kg, ctn, pcs)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = reorder, onValueChange = { reorder = it }, label = { Text("Reorder threshold") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("Default unit price") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        if (saved) Text("✓ Product saved", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                InventoryRepository.addProduct(
                    sku = sku, name = name, unit = unit.ifBlank { "pcs" }, category = category.ifBlank { "General" },
                    reorderThreshold = reorder.toDoubleOrNull() ?: 0.0, defaultUnitPrice = price.toDoubleOrNull() ?: 0.0,
                )
                sku = ""; name = ""; unit = ""; category = ""; reorder = ""; price = ""
                saved = true
            },
            colors = ButtonDefaults.buttonColors(containerColor = DeepIndigo),
            enabled = name.isNotBlank(),
        ) { Text("Save product") }
    }
}

@Composable
private fun DropdownPicker(options: List<Pair<String, String>>, selectedId: String?, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val label = options.firstOrNull { it.first == selectedId }?.second ?: "Select…"
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(label) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { (id, name) ->
                DropdownMenuItem(text = { Text(name) }, onClick = { onSelect(id); expanded = false })
            }
        }
    }
}
