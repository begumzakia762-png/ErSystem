package com.abm.erp.ui.advisory

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.MockRepository
import com.abm.erp.data.RiskBand
import com.abm.erp.theme.*

@Composable
fun BoardroomScreen() {
    val history by MockRepository.boardroomHistory.collectAsState()
    var question by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Boardroom", style = MaterialTheme.typography.headlineSmall)
            Text("Owner-only strategic advisory · conversational BI over live operational data", style = MaterialTheme.typography.bodyMedium)
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Ask in Bengali or English", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = question,
                        onValueChange = { question = it },
                        placeholder = { Text("আমাদের বরিশাল জোনে প্রফিট মার্জিন ড্রপ করার আসল কারণ কী?") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyan, unfocusedBorderColor = GlassBorder),
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(onClick = {
                        if (question.isNotBlank()) {
                            MockRepository.askBoardroom(question)
                            question = ""
                        }
                    }) {
                        Icon(Icons.Filled.Send, contentDescription = "Ask", tint = ElectricCyan)
                    }
                }
            }
        }

        items(history.reversed()) { qa ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(qa.question, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(6.dp))
                Text(qa.answer, style = MaterialTheme.typography.bodyMedium)
            }
        }

        item { Text("Daily prescription feed", style = MaterialTheme.typography.titleMedium) }
        items(MockRepository.prescriptions) { p ->
            val color = when (p.severity) { RiskBand.RED -> DangerRed; RiskBand.YELLOW -> WarningAmber; RiskBand.GREEN -> SuccessGreen }
            GlassCard(borderColor = color.copy(alpha = 0.6f), modifier = Modifier.fillMaxWidth()) {
                Text(p.title, fontWeight = FontWeight.Bold, color = color)
                Spacer(Modifier.height(4.dp))
                Text(p.body, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
