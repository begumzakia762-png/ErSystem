package com.abm.erp.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

private val ABMDarkColors = darkColorScheme(
    primary = ElectricCyan,
    secondary = DeepIndigo,
    background = ObsidianBg,
    surface = ObsidianBgAlt,
    onPrimary = Color.White,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    error = DangerRed,
)

/** Pitch-black obsidian backdrop with a subtle cyan/indigo mesh gradient. */
@Composable
fun ObsidianMeshBackground(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(DeepIndigo.copy(alpha = 0.18f), ObsidianBg),
                    radius = 1400f,
                )
            )
            .background(
                Brush.linearGradient(
                    colors = listOf(ElectricCyan.copy(alpha = 0.06f), Color.Transparent, DeepIndigo.copy(alpha = 0.10f))
                )
            )
    ) {
        content()
    }
}

@Composable
fun ABMErpTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ABMDarkColors,
        typography = ABMTypography,
        content = { ObsidianMeshBackground { content() } }
    )
}
