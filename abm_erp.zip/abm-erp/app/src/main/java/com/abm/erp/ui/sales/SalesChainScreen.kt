package com.abm.erp.ui.sales

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.*
import com.abm.erp.data.MockRepository
import com.abm.erp.data.OrderStage
import com.abm.erp.theme.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** Draft state for the new-order dual-control form: fields the AI agent can pre-fill, human can overwrite. */
data class NewOrderDraft(
    val retailerName: DualControlValue<String> = DualControlValue(""),
    val items: DualControlValue<String> = DualControlValue(""),
    val amount: DualControlValue<String> = DualControlValue(""),
)

class SalesChainViewModel : ViewModel() {
    private val _draft = MutableStateFlow(NewOrderDraft())
    val draft: StateFlow<NewOrderDraft> = _draft.asStateFlow()

    private val _lastAgentAction = MutableStateFlow<String?>(
        "Pre-filled order for \"Green Valley Store\" from field SO voice note."
    )
    val lastAgentAction: StateFlow<String?> = _lastAgentAction.asStateFlow()

    // গ্রাউন্ড-লেভেল ডাটা কালেকশন: দোকানের ছবি + GPS ট্যাগ, submit-এর আগে ধরে রাখা।
    private val _photoUri = MutableStateFlow<android.net.Uri?>(null)
    val photoUri: StateFlow<android.net.Uri?> = _photoUri.asStateFlow()
    private val _gpsTag = MutableStateFlow<Pair<Double, Double>?>(null)
    val gpsTag: StateFlow<Pair<Double, Double>?> = _gpsTag.asStateFlow()

    fun setPhoto(uri: android.net.Uri?) { _photoUri.value = uri }
    fun setGps(lat: Double, lng: Double) { _gpsTag.value = lat to lng }

    fun updateRetailer(v: String) = _draft.update { it.copy(retailerName = DualControlValue(v, FieldSource.HUMAN)) }
    fun updateItems(v: String) = _draft.update { it.copy(items = DualControlValue(v, FieldSource.HUMAN)) }
    fun updateAmount(v: String) = _draft.update { it.copy(amount = DualControlValue(v, FieldSource.HUMAN)) }

    fun submitOrder(zone: String) {
        val d = _draft.value
        if (d.retailerName.value.isBlank()) return
        MockRepository.logNewOrder(
            d.retailerName.value, d.items.value, d.amount.value.toDoubleOrNull() ?: 0.0, zone,
            photoUri = _photoUri.value?.toString(), lat = _gpsTag.value?.first, lng = _gpsTag.value?.second,
        )
        _draft.value = NewOrderDraft()
        _photoUri.value = null
        _gpsTag.value = null
        _lastAgentAction.value = null
    }
}

@Composable
fun SalesChainScreen(vm: SalesChainViewModel = viewModel()) {
    val orders by MockRepository.orders.collectAsState()
    val dealers by MockRepository.dealers.collectAsState()
    val draft by vm.draft.collectAsState()
    val lastAgentAction by vm.lastAgentAction.collectAsState()
    var tab by remember { mutableStateOf(0) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Sales Chain", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        TabRow(selectedTabIndex = tab, containerColor = Color.Transparent, contentColor = ElectricCyan) {
            listOf("SO Order Entry", "ASM Verify", "Bulk Dealer").forEachIndexed { i, label ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(label) })
            }
        }
        Spacer(Modifier.height(12.dp))

        when (tab) {
            0 -> SoOrderEntryTab(vm, draft, lastAgentAction)
            1 -> AsmVerifyTab(orders, dealers)
            2 -> BulkDealerTab(dealers)
        }
    }
}

@Composable
private fun SoOrderEntryTab(vm: SalesChainViewModel, draft: NewOrderDraft, lastAgentAction: String?) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val photoUri by vm.photoUri.collectAsState()
    val gpsTag by vm.gpsTag.collectAsState()
    var gpsError by remember { mutableStateOf<String?>(null) }

    val photoLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent(),
    ) { uri -> vm.setPhoto(uri) }

    fun hasLocationPermission() = androidx.core.content.ContextCompat.checkSelfPermission(
        context, android.Manifest.permission.ACCESS_FINE_LOCATION,
    ) == android.content.pm.PackageManager.PERMISSION_GRANTED

    fun tagLocationNow() {
        val client = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(context)
        try {
            @Suppress("MissingPermission")
            client.lastLocation.addOnSuccessListener { loc ->
                if (loc != null) { vm.setGps(loc.latitude, loc.longitude); gpsError = null }
                else gpsError = "No recent GPS fix — move to an open area and try again."
            }.addOnFailureListener { gpsError = it.message ?: "Couldn't fetch location." }
        } catch (e: SecurityException) {
            gpsError = "Location permission needed."
        }
    }

    val locationPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission(),
    ) { granted -> if (granted) tagLocationNow() else gpsError = "Location permission was denied." }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { AgentActivityBanner(lastAgentAction) { } }
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Log new retail order", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                DualControlTextField("Retailer name", draft.retailerName, vm::updateRetailer)
                Spacer(Modifier.height(10.dp))
                DualControlTextField("Items", draft.items, vm::updateItems)
                Spacer(Modifier.height(10.dp))
                DualControlTextField("Amount (৳)", draft.amount, vm::updateAmount)
                Spacer(Modifier.height(12.dp))

                // গ্রাউন্ড-লেভেল ডাটা কালেকশন: দোকানের ছবি + GPS ট্যাগ
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { photoLauncher.launch("image/*") }, modifier = Modifier.weight(1f)) {
                        Text(if (photoUri != null) "📷 Photo added ✓" else "📷 Add shop photo", style = MaterialTheme.typography.labelSmall)
                    }
                    OutlinedButton(
                        onClick = { if (hasLocationPermission()) tagLocationNow() else locationPermissionLauncher.launch(android.Manifest.permission.ACCESS_FINE_LOCATION) },
                        modifier = Modifier.weight(1f),
                    ) {
                        Text(gpsTag?.let { "📍 ${"%.3f".format(it.first)}, ${"%.3f".format(it.second)}" } ?: "📍 Tag location", style = MaterialTheme.typography.labelSmall)
                    }
                }
                gpsError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }

                Spacer(Modifier.height(14.dp))
                ManualSubmitBar("Submit Order → notifies Area Manager") { vm.submitOrder("Barisal") }
            }
        }
    }
}

@Composable
private fun AsmVerifyTab(orders: List<com.abm.erp.data.RetailOrder>, dealers: List<com.abm.erp.data.Dealer>) {
    val pending = orders.filter { it.stage == OrderStage.SO_LOGGED }
    val routed = orders.filter { it.stage != OrderStage.SO_LOGGED }
    var qrOpenFor by remember { mutableStateOf<String?>(null) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Awaiting verification (${pending.size})", style = MaterialTheme.typography.titleMedium) }
        items(pending) { order ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("${order.retailerName} · ${order.zone}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text(order.items, style = MaterialTheme.typography.bodyMedium)
                Text("৳${"%,.0f".format(order.amount)}", color = ElectricCyan, fontWeight = FontWeight.Bold)
                if (order.retailerPhotoUri != null || order.retailerLat != null) {
                    Text(
                        buildString {
                            if (order.retailerPhotoUri != null) append("📷 photo on file  ")
                            if (order.retailerLat != null) append("📍 ${"%.3f".format(order.retailerLat)}, ${"%.3f".format(order.retailerLng)}")
                        },
                        style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                    )
                }
                order.retailerQrCode?.let { code ->
                    Spacer(Modifier.height(6.dp))
                    TextButton(onClick = { qrOpenFor = if (qrOpenFor == order.id) null else order.id }) {
                        Text(if (qrOpenFor == order.id) "Hide QR" else "🔳 View shop QR code")
                    }
                    if (qrOpenFor == order.id) {
                        val bitmap = remember(code) { com.abm.erp.util.QrCodeGenerator.generate(code, 300) }
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = "QR code for $code",
                            modifier = Modifier.size(140.dp),
                        )
                        Text(code, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("Print this and stick it at the shop; scanning it later pulls up ${order.retailerName}'s data instantly.", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val nearestDealer = dealers.firstOrNull { it.zone == order.zone } ?: dealers.first()
                    Button(
                        onClick = { MockRepository.advanceOrder(order.id, OrderStage.DEALER_ROUTED, nearestDealer.id) },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)
                    ) { Text("Verify → route to ${nearestDealer.name}") }
                    OutlinedButton(onClick = { MockRepository.advanceOrder(order.id, OrderStage.REJECTED) }) {
                        Text("Reject", color = DangerRed)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)); Text("In pipeline / fulfilled", style = MaterialTheme.typography.titleMedium) }
        items(routed) { order ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("${order.retailerName}", color = TextPrimary)
                    Text(order.stage.name, color = ElectricCyan, style = MaterialTheme.typography.labelSmall)
                }
                if (order.stage == OrderStage.DEALER_ROUTED) {
                    Spacer(Modifier.height(6.dp))
                    Button(onClick = { MockRepository.advanceOrder(order.id, OrderStage.FULFILLED) }) {
                        Text("Mark fulfilled → Owner panel")
                    }
                }
            }
        }
    }
}

@Composable
private fun BulkDealerTab(dealers: List<com.abm.erp.data.Dealer>) {
    var dealerId by remember { mutableStateOf(dealers.first().id) }
    var items by remember { mutableStateOf("") }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Bulk procurement request (Area Manager → Warehouse)", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                DualControlDropdown(
                    "Dealer",
                    DualControlValue(dealers.first { it.id == dealerId }.name, FieldSource.HUMAN),
                    dealers.map { it.name },
                    onManualSelect = { name -> dealerId = dealers.first { it.name == name }.id }
                )
                Spacer(Modifier.height(10.dp))
                DualControlTextField("Items requested", DualControlValue(items, FieldSource.HUMAN), { items = it })
                Spacer(Modifier.height(14.dp))
                ManualSubmitBar("Submit to warehouse") { items = "" }
            }
        }
    }
}
