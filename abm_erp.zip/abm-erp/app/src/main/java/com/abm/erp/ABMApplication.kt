package com.abm.erp

import android.app.Application
import com.abm.erp.data.FirebaseSync
import com.abm.erp.data.InventoryRepository
import com.abm.erp.data.MockRepository

/**
 * App-level entry point. MockRepository.init() and InventoryRepository.init()
 * open/create the on-device Room database (abm_erp.db) and seed it with
 * starter data on first run. FirebaseSync.init() signs in anonymously and
 * starts listening to Firestore for the data that needs to sync across
 * different people's phones (Complaint Box, Vacant Positions today; more
 * modules move here in later phases). It fails safely if google-services.json
 * hasn't been added yet — see SETUP_FIREBASE.md.
 */
class ABMApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        MockRepository.init(this)
        InventoryRepository.init(this)
        FirebaseSync.init(this)
    }
}
