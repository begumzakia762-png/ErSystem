package com.abm.erp.data

/** One tile in the dashboard's module grid. */
data class AppModule(
    val key: String,
    val label: String,
    val category: String,
)

val CATEGORY_ORDER: List<String> = listOf(
    "Sales & Field", "Inventory & Production", "Intelligence", "Finance", "People & Admin",
)

val MODULES: List<AppModule> = listOf(
    AppModule("sales", "Sales Chain", "Sales & Field"),
    AppModule("crm", "CRM", "Sales & Field"),
    AppModule("dealer", "Dealers", "Sales & Field"),
    AppModule("gps", "GPS Track", "Sales & Field"),
    AppModule("bill", "Billing", "Sales & Field"),
    AppModule("courier", "Courier & Logistics", "Sales & Field"),
    AppModule("inv", "Inventory", "Inventory & Production"),
    AppModule("stock", "Stock Mgmt", "Inventory & Production"),
    AppModule("prod", "Production", "Inventory & Production"),
    AppModule("market", "Market Analysis", "Intelligence"),
    AppModule("ai", "AI Boardroom", "Intelligence"),
    AppModule("report", "Reports", "Intelligence"),
    AppModule("ledger", "Accounts/Ledger", "Finance"),
    AppModule("hr", "HR & Payroll", "People & Admin"),
    AppModule("approval", "Approvals", "People & Admin"),
    AppModule("tasks", "Task Manager", "People & Admin"),
    AppModule("notify", "Notifications", "People & Admin"),
    AppModule("helpdesk", "Helpdesk", "People & Admin"),
    AppModule("complaint", "Complaint Box", "People & Admin"),
)

/** Which module keys the currently-built real screens can actually open. Everything
 *  else in MODULES shows a "coming in the next update" message when tapped —
 *  honest placeholder rather than a silent no-op or a crash. */
val IMPLEMENTED_MODULE_ROUTES: Map<String, String> = mapOf(
    "sales" to "sales",
    "crm" to "crm",
    "inv" to "inventory",
    "hr" to "hrm",
    "bill" to "billing",
    "prod" to "production",
    "ai" to "boardroom",
    "complaint" to "complaint",
    "dealer" to "dealers",
    "courier" to "courier",
    "tasks" to "tasks",
    "approval" to "approvals",
    "notify" to "notifications",
    "market" to "market",
)

private val BASE = setOf("sales", "crm", "gps", "notify", "helpdesk", "complaint")

/** Per-designation module access, mirroring the JSX ROLES.allowed lists exactly. */
val ROLE_MODULES: Map<UserRole, Set<String>> = mapOf(
    UserRole.SR to BASE,
    UserRole.TSM to BASE + setOf("bill", "inv", "tasks"),
    UserRole.ASM to BASE + setOf("bill", "inv", "stock", "dealer", "courier", "tasks", "approval"),
    UserRole.RSM to BASE + setOf("bill", "inv", "stock", "dealer", "courier", "report", "tasks", "approval"),
    UserRole.DSM to BASE + setOf("bill", "inv", "stock", "dealer", "courier", "report", "market", "tasks", "approval"),
    UserRole.NSM to BASE + setOf("bill", "inv", "stock", "dealer", "courier", "market", "report", "ledger", "tasks", "approval"),
    UserRole.AGM to MODULES.map { it.key }.toSet() - "ai",
    UserRole.GM to MODULES.map { it.key }.toSet() - "ai",
    UserRole.MD to MODULES.map { it.key }.toSet(),
    UserRole.CHAIRMAN to MODULES.map { it.key }.toSet(),
)

fun visibleModulesFor(role: UserRole): List<AppModule> {
    val allowed = ROLE_MODULES[role].orEmpty()
    return MODULES.filter { it.key in allowed }
}
