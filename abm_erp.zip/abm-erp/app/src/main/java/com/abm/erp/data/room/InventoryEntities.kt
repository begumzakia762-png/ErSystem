package com.abm.erp.data.room

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val sku: String,
    val name: String,
    val unit: String,          // "ctn", "kg", "pcs"...
    val category: String,
    val reorderThreshold: Double,
    val defaultUnitPrice: Double,
)

@Entity(tableName = "warehouses")
data class WarehouseEntity(
    @PrimaryKey val id: String,
    val name: String,
    val zone: String,
    val stockCategory: String = "STORE", // "PRODUCTION" or "STORE" — see StockCategory enum in Models.kt
)

@Entity(tableName = "stock_levels", primaryKeys = ["productId", "warehouseId"])
data class StockLevelEntity(
    val productId: String,
    val warehouseId: String,
    val quantityOnHand: Double,
)

@Entity(tableName = "stock_movements")
data class StockMovementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: String,
    val warehouseId: String,
    val type: String,          // IN / OUT / ADJUST
    val quantity: Double,
    val reason: String,
    val timestampEpochMillis: Long,
)
