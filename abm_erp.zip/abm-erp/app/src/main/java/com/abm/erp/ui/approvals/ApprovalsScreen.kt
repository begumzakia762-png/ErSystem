package com.abm.erp.ui.approvals

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.ApprovalStatus
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

@Composable
fun ApprovalsScreen() {
    val approvals by MockRepository.approvals.collectAsState()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Approvals", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(4.dp))
        Text("Leave, discount, and expense requests from designations below you.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Spacer(Modifier.height(12.dp))

        if (approvals.isEmpty()) {
            Text("No approval requests right now.", color = TextSecondary)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(approvals, key = { it.id }) { req ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(req.type.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        val (label, color) = when (req.status) {
                            ApprovalStatus.PENDING -> "Pending" to WarningAmber
                            ApprovalStatus.APPROVED -> "Approved" to SuccessGreen
                            ApprovalStatus.REJECTED -> "Rejected" to DangerRed
                        }
                        Text(label, color = color, style = MaterialTheme.typography.labelSmall)
                    }
                    Text(req.fromEmployee, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(req.detail, style = MaterialTheme.typography.bodyMedium)
                    if (req.status == ApprovalStatus.PENDING) {
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { MockRepository.setApprovalStatus(req.id, ApprovalStatus.APPROVED) }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) {
                                Text("Approve")
                            }
                            OutlinedButton(onClick = { MockRepository.setApprovalStatus(req.id, ApprovalStatus.REJECTED) }) {
                                Text("Reject", color = DangerRed)
                            }
                        }
                    }
                }
            }
        }
    }
}
