package com.abm.erp.ui.login

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class LoginStatus { Idle, Checking, Error, Success }

/**
 * Entry point before the main app. Two paths in, matching the design phase:
 * 1. 5-digit PIN checked against MockRepository.demoAccounts.
 * 2. Real device fingerprint/Face unlock via BiometricPrompt, which needs
 *    the FragmentActivity host passed in from MainActivity.
 *
 * Also matches the design phase's security additions: 3 wrong PIN attempts
 * locks this device (only the Chairman's PIN unlocks it), and a simulated
 * Forgot-PIN → OTP → new-PIN flow. No demo PINs are shown on screen anymore —
 * showing credentials on a real login screen is a security anti-pattern.
 *
 * On success, calls MockRepository.completeLogin(user) then onLoginSuccess(),
 * which flips MainActivity over to the real dashboard.
 */
@Composable
fun LoginScreen(activity: FragmentActivity, onLoginSuccess: () -> Unit, onDealerLoginRequested: () -> Unit = {}) {
    var pin by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(LoginStatus.Idle) }
    var biometricError by remember { mutableStateOf<String?>(null) }
    val shakeOffset = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    val demoAccounts by MockRepository.demoAccountsFlow.collectAsState()
    val deviceLocked by MockRepository.deviceLocked.collectAsState()

    // ---- Admin-unlock sub-flow (only shown while deviceLocked) ----
    var unlockPin by remember { mutableStateOf("") }
    var unlockError by remember { mutableStateOf<String?>(null) }

    // ---- Forgot-PIN sub-flow: 0 = off, 1 = phone, 2 = OTP, 3 = new PIN, 4 = done ----
    var forgotStep by remember { mutableStateOf(0) }
    var forgotPhone by remember { mutableStateOf("") }
    var forgotOtp by remember { mutableStateOf("") }
    var forgotNewPin by remember { mutableStateOf("") }
    var forgotError by remember { mutableStateOf<String?>(null) }

    fun reset() {
        pin = ""
        status = LoginStatus.Idle
    }

    fun attemptLogin(code: String) {
        status = LoginStatus.Checking
        scope.launch {
            delay(400) // small pause so "Verifying..." is visible, matches the design prototype
            val user = demoAccounts[code]
            if (user != null) {
                status = LoginStatus.Success
                MockRepository.completeLogin(user)
                MockRepository.unlockDevice() // successful login clears any prior failed-attempt count
                delay(650)
                onLoginSuccess()
            } else {
                status = LoginStatus.Error
                shakeOffset.animateTo(20f, tween(50))
                shakeOffset.animateTo(-20f, tween(80))
                shakeOffset.animateTo(12f, tween(80))
                shakeOffset.animateTo(0f, tween(80))
                delay(500)
                reset()
                // ৩ বার ভুল হলে ডিভাইস লক হয়ে যাবে — Chairman-এর PIN ছাড়া আনলক হবে না।
                MockRepository.recordFailedPinAttempt()
            }
        }
    }

    fun pressUnlock(digit: String) {
        if (unlockPin.length >= 5) return
        val next = unlockPin + digit
        unlockPin = next
        if (next.length == 5) {
            if (MockRepository.isChairmanPin(next)) {
                MockRepository.unlockDevice()
                unlockPin = ""
                unlockError = null
            } else {
                unlockError = "Incorrect Admin PIN."
                scope.launch { delay(500); unlockPin = "" }
            }
        }
    }

    fun startBiometric() {
        val canAuth = BiometricManager.from(activity)
            .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.BIOMETRIC_STRONG)
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            biometricError = when (canAuth) {
                BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE ->
                    "This device has no fingerprint/face hardware — use your PIN instead."
                BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE ->
                    "Fingerprint/face hardware is busy or unavailable right now — use your PIN, or try again shortly."
                BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED ->
                    "No fingerprint/face enrolled on this device — set one up in phone Settings, or use your PIN."
                BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED ->
                    "This device needs a security update before fingerprint/face unlock will work — use your PIN for now."
                else -> "Fingerprint/face unlock isn't available right now — use your PIN."
            }
            return
        }
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    // biometric login always signs in as whichever account is currently the Chairman's PIN
                    val chairmanEntry = MockRepository.demoAccounts.entries.firstOrNull { it.value.role.name == "CHAIRMAN" }
                    val user = chairmanEntry?.value ?: MockRepository.demoAccounts.values.first()
                    MockRepository.completeLogin(user)
                    MockRepository.unlockDevice()
                    onLoginSuccess()
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    biometricError = errString.toString()
                }
            },
        )
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock ABM Corporation")
            .setSubtitle("Use your fingerprint or face to sign in")
            .setNegativeButtonText("Use PIN instead")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build()
        prompt.authenticate(promptInfo)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(SkyTop, Sky, SkyHorizon, GoldBright)),
            ),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 32.dp, vertical = 48.dp)
                .offset(x = shakeOffset.value.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            // ---- brand ----
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                AnimatedVisibility(visible = true, enter = scaleIn(tween(500)) + fadeIn(tween(500))) {
                    Box(
                        modifier = Modifier
                            .size(84.dp)
                            .background(
                                Brush.linearGradient(listOf(GoldBright, Gold, GoldDeep)),
                                shape = CircleShape,
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("ABM", color = Color(0xFF241A08), fontWeight = FontWeight.Bold, fontSize = 24.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(
                    "ABM Corporation",
                    color = Color(0xFFFCFAF3),
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                )
                Spacer(Modifier.height(4.dp))
                Text("by Prime Distribution", color = Color.Black, fontSize = 11.sp)
            }

            when {
                deviceLocked -> {
                    // ================= Device locked out (3 wrong attempts) =================
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text("🔒", fontSize = 34.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Too many incorrect attempts", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "This device is locked. Only the Chairman's PIN can unlock it.",
                            color = Color(0xFFE4EEF6), fontSize = 11.5.sp,
                        )
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            repeat(5) { i ->
                                val filled = i < unlockPin.length
                                Box(
                                    modifier = Modifier.size(13.dp)
                                        .background(if (filled) GoldBright else Color.Transparent, CircleShape)
                                        .border(2.dp, if (filled) GoldBright else Color(0x55FFFFFF), CircleShape),
                                )
                            }
                        }
                        unlockError?.let { Text(it, color = DangerRed, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)) }
                        Spacer(Modifier.height(16.dp))
                        val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "del"))
                        rows.forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(bottom = 12.dp)) {
                                row.forEach { key ->
                                    when {
                                        key.isEmpty() -> Spacer(Modifier.size(52.dp))
                                        key == "del" -> IconButton(onClick = { unlockPin = unlockPin.dropLast(1) }, modifier = Modifier.size(52.dp)) {
                                            Icon(Icons.Filled.Backspace, contentDescription = "Delete", tint = Color(0xFFE4EEF6))
                                        }
                                        else -> OutlinedButton(
                                            onClick = { pressUnlock(key) },
                                            modifier = Modifier.size(52.dp), shape = RoundedCornerShape(18.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFCFAF3)),
                                        ) { Text(key, fontSize = 19.sp, fontWeight = FontWeight.SemiBold) }
                                    }
                                }
                            }
                        }
                        Text("Admin PIN unlock — Chairman only", color = Color(0xFFE4EEF6), fontSize = 10.sp)
                    }
                }

                forgotStep > 0 -> {
                    // ================= Forgot PIN → OTP flow (simulated) =================
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        when (forgotStep) {
                            1 -> {
                                Text("Reset your PIN", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = forgotPhone, onValueChange = { forgotPhone = it },
                                    placeholder = { Text("Registered mobile number") }, modifier = Modifier.fillMaxWidth(),
                                )
                                forgotError?.let { Text(it, color = DangerRed, fontSize = 11.sp) }
                                Spacer(Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        if (forgotPhone.isBlank()) forgotError = "Enter your registered mobile number."
                                        else { forgotError = null; forgotStep = 2 }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                ) { Text("Send OTP") }
                            }
                            2 -> {
                                Text("Enter the OTP", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(Modifier.height(6.dp))
                                Text("Sent to $forgotPhone. (Demo OTP: 0000)", color = Color(0xFFE4EEF6), fontSize = 11.sp)
                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = forgotOtp, onValueChange = { forgotOtp = it.filter(Char::isDigit).take(4) },
                                    placeholder = { Text("4-digit OTP") }, modifier = Modifier.fillMaxWidth(),
                                )
                                forgotError?.let { Text(it, color = DangerRed, fontSize = 11.sp) }
                                Spacer(Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        if (forgotOtp != "0000") forgotError = "Incorrect OTP."
                                        else { forgotError = null; forgotStep = 3 }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                ) { Text("Verify OTP") }
                            }
                            3 -> {
                                Text("Set a new 5-digit PIN", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = forgotNewPin, onValueChange = { forgotNewPin = it.filter(Char::isDigit).take(5) },
                                    placeholder = { Text("New PIN") }, modifier = Modifier.fillMaxWidth(),
                                )
                                forgotError?.let { Text(it, color = DangerRed, fontSize = 11.sp) }
                                Spacer(Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        if (forgotNewPin.length != 5) forgotError = "New PIN must be 5 digits."
                                        else {
                                            forgotError = null
                                            forgotStep = 4
                                            scope.launch { delay(2000); forgotStep = 0; forgotPhone = ""; forgotOtp = ""; forgotNewPin = "" }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                ) { Text("Save new PIN") }
                            }
                            4 -> Text("✓ PIN reset — please log in with it next time.", color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        if (forgotStep < 4) {
                            TextButton(onClick = { forgotStep = 0; forgotError = null }) {
                                Text("← Back to login", color = Color(0xFFE4EEF6), fontSize = 11.sp)
                            }
                        }
                    }
                }

                else -> {
                    // ================= Normal PIN entry =================
                    // ---- PIN entry ----
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = when (status) {
                                LoginStatus.Checking -> "Verifying…"
                                LoginStatus.Error -> "Incorrect PIN — try again"
                                else -> "Enter your 5-digit PIN"
                            },
                            color = Color(0xFFE4EEF6),
                            fontSize = 13.sp,
                        )
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            repeat(5) { i ->
                                val filled = i < pin.length
                                val dotColor = if (status == LoginStatus.Error) DangerRed else GoldBright
                                Box(
                                    modifier = Modifier
                                        .size(14.dp)
                                        .background(color = if (filled) dotColor else Color.Transparent, shape = CircleShape)
                                        .border(width = 2.dp, color = if (filled) dotColor else Color(0x55FFFFFF), shape = CircleShape),
                                )
                            }
                        }
                        if (status == LoginStatus.Checking) {
                            Spacer(Modifier.height(10.dp))
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = GoldBright)
                        }
                    }

                    // ---- keypad ----
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "del"))
                        rows.forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(bottom = 14.dp)) {
                                row.forEach { key ->
                                    when {
                                        key.isEmpty() -> Spacer(Modifier.size(58.dp))
                                        key == "del" -> {
                                            IconButton(
                                                onClick = { if (pin.isNotEmpty() && status == LoginStatus.Idle) pin = pin.dropLast(1) },
                                                modifier = Modifier.size(58.dp),
                                            ) { Icon(Icons.Filled.Backspace, contentDescription = "Delete", tint = Color(0xFFE4EEF6)) }
                                        }
                                        else -> {
                                            OutlinedButton(
                                                onClick = {
                                                    if (status != LoginStatus.Idle) return@OutlinedButton
                                                    if (pin.length < 5) {
                                                        pin += key
                                                        if (pin.length == 5) attemptLogin(pin)
                                                    }
                                                },
                                                modifier = Modifier.size(58.dp),
                                                shape = RoundedCornerShape(18.dp),
                                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFCFAF3)),
                                            ) { Text(key, fontSize = 20.sp, fontWeight = FontWeight.SemiBold) }
                                        }
                                    }
                                }
                            }
                        }

                        TextButton(onClick = { startBiometric() }) {
                            Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = Color(0xFFFCFAF3))
                            Spacer(Modifier.width(6.dp))
                            Text("Fingerprint / Face unlock", color = Color(0xFFFCFAF3), fontSize = 12.sp)
                        }
                        biometricError?.let {
                            Text(it, color = Color(0xFF241A08), fontSize = 10.sp, modifier = Modifier.padding(horizontal = 24.dp))
                        }
                        // demo PIN hint সরিয়ে দেওয়া হলো — real app-এ login screen-এ
                        // password/PIN দেখানো একটা স্পষ্ট নিরাপত্তা ভুল।
                        TextButton(onClick = { forgotStep = 1 }) {
                            Text("Forgot PIN?", color = Color(0xFFE4EEF6), fontSize = 11.5.sp)
                        }
                        // ডিলার লগইন — স্টাফ PIN থেকে সম্পূর্ণ আলাদা পথ (ডিলার
                        // কোম্পানির staff hierarchy-র অংশ না, বহিরাগত পার্টনার)।
                        OutlinedButton(onClick = onDealerLoginRequested) {
                            Text("🏪 Continue as Dealer", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        if (status == LoginStatus.Success) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = SuccessGreen)
                    Spacer(Modifier.height(12.dp))
                    Text("Welcome, ${MockRepository.currentUser.name}", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
