package com.abm.erp.core

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.theme.*

/**
 * Represents a single form field's value plus provenance: was it last set by the
 * AI agent, or by a manual human edit? The UI always renders an editable control
 * regardless of source, and any manual edit immediately flips the source to HUMAN
 * and becomes the value of record.
 */
enum class FieldSource { HUMAN, AI, UNSET }

data class DualControlValue<T>(
    val value: T,
    val source: FieldSource = FieldSource.UNSET,
)

/** Base translucent glass card used across every module screen. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    borderColor: Color = GlassBorder,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(GlassSurface)
            .border(BorderStroke(1.dp, borderColor), RoundedCornerShape(18.dp))
            .padding(16.dp),
        content = content,
    )
}

/** Small pill indicating whether the current field value came from the AI agent or a human edit. */
@Composable
fun ProvenanceTag(source: FieldSource) {
    if (source == FieldSource.UNSET) return
    val (label, color) = if (source == FieldSource.AI) "AI-filled" to ElectricCyan else "Manually set" to SuccessGreen
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Icon(
            if (source == FieldSource.AI) Icons.Filled.AutoAwesome else Icons.Filled.Edit,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(11.dp)
        )
        Spacer(Modifier.width(4.dp))
        Text(label, fontSize = 10.sp, color = color, fontWeight = FontWeight.Medium)
    }
}

/**
 * A text field the AI agent can populate programmatically via [value], but which the
 * human can always tap into and overwrite. Any keystroke here calls [onManualChange],
 * which the caller should use to overwrite the store's value with source = HUMAN,
 * permanently taking precedence over whatever the agent last wrote.
 */
@Composable
fun DualControlTextField(
    label: String,
    state: DualControlValue<String>,
    onManualChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    keyboardHintNumeric: Boolean = false,
) {
    Column(modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.width(6.dp))
            ProvenanceTag(state.source)
        }
        Spacer(Modifier.height(4.dp))
        OutlinedTextField(
            value = state.value,
            onValueChange = onManualChange,
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ElectricCyan,
                unfocusedBorderColor = GlassBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
            ),
        )
    }
}

/** Dropdown variant of the same dual-control contract. */
@Composable
fun DualControlDropdown(
    label: String,
    state: DualControlValue<String>,
    options: List<String>,
    onManualSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var expanded by remember { mutableStateOf(false) }
    Column(modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.width(6.dp))
            ProvenanceTag(state.source)
        }
        Spacer(Modifier.height(4.dp))
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(state.value.ifBlank { "Select…" }, color = TextPrimary)
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { opt ->
                    DropdownMenuItem(text = { Text(opt) }, onClick = {
                        onManualSelect(opt)
                        expanded = false
                    })
                }
            }
        }
    }
}

/**
 * Banner shown at the top of every dual-control screen: surfaces the agent's last
 * action in plain language and gives one tap to undo/override it, so the human
 * always has final execution authority before anything posts.
 */
@Composable
fun AgentActivityBanner(
    lastAgentAction: String?,
    onReview: () -> Unit,
) {
    if (lastAgentAction == null) return
    GlassCard(borderColor = ElectricCyan.copy(alpha = 0.5f), modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = ElectricCyan)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Agent action", style = MaterialTheme.typography.labelSmall)
                Text(lastAgentAction, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
            }
            TextButton(onClick = onReview) { Text("Review", color = ElectricCyan) }
        }
    }
}

/** Manual save / submit control — always present, always enabled, final say belongs to the human. */
@Composable
fun ManualSubmitBar(
    label: String = "Save & Submit",
    enabled: Boolean = true,
    onSubmit: () -> Unit,
) {
    Button(
        onClick = onSubmit,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = Color.Black),
        shape = RoundedCornerShape(12.dp),
    ) {
        Text(label, fontWeight = FontWeight.SemiBold)
    }
}
