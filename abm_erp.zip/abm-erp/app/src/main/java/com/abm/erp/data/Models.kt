package com.abm.erp.data

import java.time.LocalDate
import java.time.LocalDateTime

// ---------- Multi-tenant / roles ----------
// Real chain of command: SR -> TSM -> ASM -> RSM -> DSM -> NSM -> AGM -> GM -> MD -> CHAIRMAN.
// Each designation's module access is enforced in MockRepository.allowedModules(); zone/geo
// scoping (which district/division a person's data is limited to) lives on AppUser.zone.
enum class UserRole { SR, TSM, ASM, RSM, DSM, NSM, AGM, GM, MD, CHAIRMAN }

data class Company(val id: String, val name: String) // e.g. "ABM Corporation"

data class AppUser(
    val id: String,
    val name: String,
    val role: UserRole,
    val companyId: String,
    val zone: String, // geo scope label, e.g. "Rangpur district" or "All Bangladesh · Board" for Chairman
    val employeeId: String, // links to the richer Employee record in OrgDirectory.kt
)

// ---------- Sales chain ----------

enum class OrderStage { SO_LOGGED, ASM_VERIFIED, DEALER_ROUTED, FULFILLED, REJECTED }

data class RetailOrder(
    val id: String,
    val retailerName: String,
    val loggedBySoId: String,
    val zone: String,
    val items: String,          // e.g. "ABM Masala Tea x40 ctn"
    val amount: Double,
    var stage: OrderStage = OrderStage.SO_LOGGED,
    var routedDealerId: String? = null,
    val loggedAt: LocalDateTime = LocalDateTime.now(),
    // Ground-level SR data collection: shop photo, live GPS tag, and a
    // printable QR code unique to this retailer — scan it later to pull the
    // shop's record back up instantly.
    val retailerPhotoUri: String? = null,
    val retailerLat: Double? = null,
    val retailerLng: Double? = null,
    val retailerQrCode: String? = null,
)

data class Dealer(
    val id: String,
    val name: String,
    val zone: String,
    var dueBalance: Double,
    var salesLast90Days: Double,
)

data class BulkDealerRequest(
    val id: String,
    val dealerId: String,
    val requestedByAsmId: String,
    val items: String,
    val warehouseAvailable: Boolean,
)

// ---------- Geotagged CRM ----------

data class GpsPing(val lat: Double, val lng: Double, val timestamp: LocalDateTime, val spoofed: Boolean = false)

data class FieldEmployeeRoute(
    val employeeId: String,
    val employeeName: String,
    val date: LocalDate,
    val breadcrumbs: List<GpsPing>,
)

enum class CampaignChannel { ROBOCALL_BN, SMS, EMAIL }

data class EngagementCampaign(
    val id: String,
    val channel: CampaignChannel,
    val message: String,
    val targetZone: String,
    val sentCount: Int = 0,
)

// ---------- HRM & Payroll ----------

data class AttendanceRecord(
    val employeeId: String,
    val date: LocalDate,
    val checkedIn: Boolean,
    val gpsValid: Boolean, // false => spoofed/missing node => triggers penalty
)

data class PayrollLine(
    val employeeId: String,
    val employeeName: String,
    val basePay: Double,
    val targetAmount: Double,
    val achievedAmount: Double,
    val commissionRate: Double,     // e.g. 0.02 = 2%
    val unapprovedAbsenceDays: Int,
    val dailyWage: Double,
) {
    val achievementPct: Double get() = if (targetAmount == 0.0) 0.0 else (achievedAmount / targetAmount) * 100
    val scalingFactor: Double get() = (achievementPct / 100).coerceIn(0.5, 1.5) // 50%-150% curve
    val commission: Double get() = achievedAmount * commissionRate
    val absencePenalty: Double get() = unapprovedAbsenceDays * dailyWage
    val netPayable: Double get() = (basePay * scalingFactor) + commission - absencePenalty
}

// ---------- Credit risk, billing, payments ----------

enum class RiskBand { GREEN, YELLOW, RED }

data class InvoiceLineItem(val name: String, var qty: Double, var unit: String, var unitPrice: Double, var discountPct: Double) {
    val lineTotal: Double get() = qty * unitPrice * (1 - discountPct / 100)
}

data class VoiceInvoice(
    val id: String,
    val dealerId: String,
    val items: MutableList<InvoiceLineItem>,
    var previousDue: Double,
) {
    val subtotal: Double get() = items.sumOf { it.lineTotal }
    val netOutstanding: Double get() = subtotal + previousDue
}

enum class PaymentVerificationStatus { PENDING_VERIFICATION, VERIFIED, REJECTED }

data class PaymentProof(
    val id: String,
    val dealerId: String,
    val amount: Double,
    val proofRef: String, // slip photo / txn id reference
    var status: PaymentVerificationStatus = PaymentVerificationStatus.PENDING_VERIFICATION,
)

// ---------- Factory / production ----------

data class RawMaterialLot(
    val id: String,
    val materialName: String, // "Raw Leaves", "CMC Thickener", "Packaging"
    val qtyKg: Double,
    val costPerKg: Double,
    val purchasedOn: LocalDate,
)

data class ProductionBatch(
    val id: String,
    val cycleType: String, // "Spray Dryer 30kg" / "Drum Dryer 30kg"
    val inputKg: Double,
    val outputKg: Double,
    var gatepassReceived: Boolean = false,
)

data class FactoryAttendance(
    val laborerId: String,
    val date: LocalDate,
    val withinFactoryGeofence: Boolean,
    val wifiIpLocked: Boolean,
)

// ---------- BI / advisory ----------

data class PrescriptionCard(
    val id: String,
    val title: String,
    val body: String,
    val severity: RiskBand,
)

data class BoardroomQuery(val question: String, val answer: String, val askedAt: LocalDateTime = LocalDateTime.now())

// ---------- Task Manager ----------

data class TaskItem(
    val id: String,
    val title: String,
    val assignee: String,
    var done: Boolean = false,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ---------- Approvals ----------
// Generic approval-request inbox: leave, discount, expense, etc. Distinct
// from the Sales Chain's order verification (SO_LOGGED -> ASM_VERIFIED),
// which is its own dedicated flow — this is for everything else that needs
// a "someone above me signs off" step.

enum class ApprovalType { LEAVE, DISCOUNT, EXPENSE, OTHER }
enum class ApprovalStatus { PENDING, APPROVED, REJECTED }

data class ApprovalRequest(
    val id: String,
    val type: ApprovalType,
    val fromEmployee: String,
    val detail: String,
    var status: ApprovalStatus = ApprovalStatus.PENDING,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ---------- Courier & Logistics ----------

data class CourierPartner(val id: String, val name: String, val hasApi: Boolean)

enum class ShipmentStatus { PICKED_UP, IN_TRANSIT, OUT_FOR_DELIVERY, DELIVERED }

data class Shipment(
    val id: String,
    val courierId: String,
    val dealerOrRetailer: String,
    val trackingId: String?,
    var status: ShipmentStatus = ShipmentStatus.PICKED_UP,
)

// ---------- Stock category (Production vs Store split) ----------
// "Company-wide stock across both categories is mainly the Admin/Chairman's
// concern — SR/ASM/TSM mostly only touch the Store side (dealer fulfillment)."
enum class StockCategory { PRODUCTION, STORE }
