package com.abm.erp.ui.billing

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.*
import com.abm.erp.data.*
import com.abm.erp.theme.*

@Composable
fun CreditAndBillingScreen() {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Credit Risk & Billing", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        TabRow(selectedTabIndex = tab, containerColor = Color.Transparent, contentColor = ElectricCyan) {
            listOf("Risk Matrix", "Voice Billing", "Payments").forEachIndexed { i, label ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(label) })
            }
        }
        Spacer(Modifier.height(12.dp))
        when (tab) {
            0 -> RiskMatrixTab()
            1 -> VoiceBillingTab()
            else -> PaymentsTab()
        }
    }
}

@Composable
private fun RiskMatrixTab() {
    val dealers by MockRepository.dealers.collectAsState()
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(dealers) { d ->
            val band = MockRepository.riskBand(d)
            val color = when (band) { RiskBand.GREEN -> RiskGreen; RiskBand.YELLOW -> RiskYellow; RiskBand.RED -> RiskRed }
            GlassCard(borderColor = color.copy(alpha = 0.6f), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(d.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text(d.zone, style = MaterialTheme.typography.labelSmall)
                    }
                    Text(band.name, color = color, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Text("Due: ৳${"%,.0f".format(d.dueBalance)}  ·  Sales (90d): ৳${"%,.0f".format(d.salesLast90Days)}", style = MaterialTheme.typography.bodyMedium)
                val ratio = if (d.salesLast90Days == 0.0) 1f else (d.dueBalance / d.salesLast90Days).toFloat().coerceIn(0f, 1f)
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(progress = ratio, color = color, trackColor = color.copy(alpha = 0.15f), modifier = Modifier.fillMaxWidth())
                if (band == RiskBand.RED) {
                    Spacer(Modifier.height(6.dp))
                    Text("⚠ New order intake locked — due balance exceeds threshold", color = DangerRed, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun VoiceBillingTab() {
    val invoices by MockRepository.invoices.collectAsState()
    val invoice = invoices.first()
    val dealers by MockRepository.dealers.collectAsState()
    val dealer = dealers.first { it.id == invoice.dealerId }

    var voiceCommand by remember { mutableStateOf("") }
    var lastAgentAction by remember { mutableStateOf<String?>(null) }
    var listening by remember { mutableStateOf(false) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { AgentActivityBanner(lastAgentAction) { lastAgentAction = null } }
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Voice command", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = voiceCommand,
                        onValueChange = { voiceCommand = it },
                        placeholder = { Text("e.g. \"Change quantity to 60kg and bump discount to 7%\"") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyan, unfocusedBorderColor = GlassBorder),
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(onClick = { listening = !listening }) {
                        Icon(Icons.Filled.Mic, contentDescription = "Voice input", tint = if (listening) DangerRed else ElectricCyan)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val result = parseVoiceCommand(voiceCommand, invoice.items.first())
                        if (result != null) {
                            MockRepository.updateInvoiceItem(invoice.id, 0, result)
                            lastAgentAction = "Applied: qty ${result.qty}${result.unit}, discount ${result.discountPct}% on \"${result.name}\""
                        } else {
                            lastAgentAction = "Could not parse that command — edit the fields below manually."
                        }
                        voiceCommand = ""
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = DeepIndigo)
                ) { Text("Apply voice command") }
            }
        }
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Invoice ${invoice.id} · ${dealer.name}", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                invoice.items.forEachIndexed { idx, item ->
                    InvoiceItemRow(item) { updated -> MockRepository.updateInvoiceItem(invoice.id, idx, updated) }
                    Spacer(Modifier.height(8.dp))
                }
                Divider(color = GlassBorder)
                Spacer(Modifier.height(8.dp))
                StatLine("Subtotal", invoice.subtotal)
                StatLine("Previous due carried forward", invoice.previousDue)
                Spacer(Modifier.height(4.dp))
                StatLine("Net Outstanding Balance", invoice.netOutstanding, bold = true)
                Spacer(Modifier.height(12.dp))
                ManualSubmitBar("Confirm & issue invoice") {}
            }
        }
    }
}

/** Very small rule-based parser standing in for real Gemini function-calling; matches the demo command shapes from the brief. */
private fun parseVoiceCommand(command: String, current: InvoiceLineItem): InvoiceLineItem? {
    if (command.isBlank()) return null
    val qtyMatch = Regex("""(\d+(\.\d+)?)\s*kg""", RegexOption.IGNORE_CASE).find(command)
    val discountMatch = Regex("""(\d+(\.\d+)?)\s*%""").find(command)
    if (qtyMatch == null && discountMatch == null) return null
    return current.copy(
        qty = qtyMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: current.qty,
        discountPct = discountMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: current.discountPct,
    )
}

@Composable
private fun InvoiceItemRow(item: InvoiceLineItem, onChange: (InvoiceLineItem) -> Unit) {
    Column {
        DualControlTextField("Item", DualControlValue(item.name, FieldSource.AI), { onChange(item.copy(name = it)) })
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DualControlTextField("Qty (${item.unit})", DualControlValue(item.qty.toString(), FieldSource.AI),
                { onChange(item.copy(qty = it.toDoubleOrNull() ?: item.qty)) }, modifier = Modifier.weight(1f))
            DualControlTextField("Discount %", DualControlValue(item.discountPct.toString(), FieldSource.AI),
                { onChange(item.copy(discountPct = it.toDoubleOrNull() ?: item.discountPct)) }, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(4.dp))
        Text("Line total: ৳${"%,.0f".format(item.lineTotal)}", color = ElectricCyan, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun StatLine(label: String, amount: Double, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text("৳${"%,.0f".format(amount)}", fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal, color = if (bold) ElectricCyan else TextPrimary)
    }
}

@Composable
private fun PaymentsTab() {
    val payments by MockRepository.payments.collectAsState()
    val dealers by MockRepository.dealers.collectAsState()
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(payments) { p ->
            val dealerName = dealers.firstOrNull { it.id == p.dealerId }?.name ?: p.dealerId
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(dealerName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text("৳${"%,.0f".format(p.amount)} · proof: ${p.proofRef}", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                when (p.status) {
                    PaymentVerificationStatus.PENDING_VERIFICATION -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { MockRepository.setPaymentStatus(p.id, PaymentVerificationStatus.VERIFIED) },
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) { Text("Verify & release") }
                        OutlinedButton(onClick = { MockRepository.setPaymentStatus(p.id, PaymentVerificationStatus.REJECTED) }) {
                            Text("Reject", color = DangerRed)
                        }
                    }
                    PaymentVerificationStatus.VERIFIED -> Text("✓ Verified & released", color = SuccessGreen, fontWeight = FontWeight.SemiBold)
                    PaymentVerificationStatus.REJECTED -> Text("✕ Rejected", color = DangerRed, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
