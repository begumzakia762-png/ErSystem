package com.abm.erp.ui.notifications

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.EMPLOYEE_DIRECTORY
import com.abm.erp.data.FirebaseSync
import com.abm.erp.data.InventoryRepository
import com.abm.erp.data.MockRepository
import com.abm.erp.data.UserRole
import com.abm.erp.data.findCoveringEmployee
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

/**
 * A single inbox pulling from every source that generates an alert, rather
 * than one screen per source — matches the JSX design's Notifications
 * concept. Low-stock reaches everyone (even SR, who doesn't manage dealers
 * directly, still benefits from knowing); vacancy-coverage duties and open
 * complaints are scoped to what's actually relevant to the viewer.
 */
@Composable
fun NotificationsScreen() {
    val appUser by MockRepository.currentUserFlow.collectAsState()
    val vacantIds by MockRepository.vacantEmployeeIds.collectAsState()
    val stockLevels by InventoryRepository.stockLevels.collectAsState()
    val complaints by FirebaseSync.complaints.collectAsState()

    val employee = remember(appUser.employeeId) {
        EMPLOYEE_DIRECTORY.firstOrNull { it.id == appUser.employeeId } ?: EMPLOYEE_DIRECTORY.first { it.role == UserRole.CHAIRMAN }
    }
    val coveredEmployees = remember(employee.id, vacantIds) {
        EMPLOYEE_DIRECTORY.filter { vacantIds.contains(it.id) && findCoveringEmployee(it, vacantIds)?.id == employee.id }
    }
    val lowStock = stockLevels.filter { it.isLowStock }
    val openComplaints = if (appUser.role == UserRole.CHAIRMAN) complaints.filter { !it.resolved } else emptyList()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Notifications", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))

        if (coveredEmployees.isEmpty() && lowStock.isEmpty() && openComplaints.isEmpty()) {
            Text("You're all caught up — nothing needs attention right now.", color = TextSecondary)
        }

        coveredEmployees.forEach { vacant ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                Text("⚠ Covering: ${vacant.name} (${vacant.role}, ${vacant.geoLabel})", color = WarningAmber, fontWeight = FontWeight.SemiBold)
                Text("This position is currently vacant — their duties route to you.", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
        }

        if (lowStock.isNotEmpty()) {
            Text("Stock alerts", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            lowStock.forEach { level ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text("${level.productName} low at ${level.warehouseName}", color = DangerRed, fontWeight = FontWeight.SemiBold)
                    Text("${"%.1f".format(level.quantityOnHand)} ${level.unit} left (reorder level: ${"%.0f".format(level.reorderThreshold)})", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }

        if (openComplaints.isNotEmpty()) {
            Text("Open complaints", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            openComplaints.forEach { c ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text(c.subject, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                    Text(if (c.anonymous) "Anonymous · ${c.fromRole}" else "${c.fromName} · ${c.fromRole}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }
    }
}
