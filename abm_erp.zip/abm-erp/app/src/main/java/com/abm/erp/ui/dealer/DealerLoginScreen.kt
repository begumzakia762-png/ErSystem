package com.abm.erp.ui.dealer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.*

/**
 * Dealer's own entry point — deliberately NOT the staff PIN pad. A dealer is
 * an external business partner, not part of the company's designation
 * hierarchy, so a simplified "pick your business" login is enough for this
 * pass (matches the JSX design's single-demo-dealer simplicity). A real
 * deployment would give each dealer their own phone-number + OTP login.
 */
@Composable
fun DealerLoginScreen(onDealerChosen: (dealerId: String) -> Unit, onBackToStaffLogin: () -> Unit) {
    val dealers by MockRepository.dealers.collectAsState()

    Box(
        modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(SkyTop, Sky, SkyHorizon, GoldBright))),
        contentAlignment = Alignment.Center,
    ) {
        Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("🏪", fontSize = 40.sp)
            Spacer(Modifier.height(12.dp))
            Text("Dealer Portal", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text("Choose your business to continue", color = Color(0xFFE4EEF6), fontSize = 12.sp)
            Spacer(Modifier.height(20.dp))
            dealers.forEach { dealer ->
                Surface(
                    onClick = { onDealerChosen(dealer.id) },
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0x22FFFFFF),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(dealer.name, color = Color(0xFFFCFAF3), fontWeight = FontWeight.SemiBold)
                        Text(dealer.zone, color = Color(0xFFE4EEF6), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            TextButton(onClick = onBackToStaffLogin) {
                Text("← Back to staff login", color = Color(0xFFE4EEF6), fontSize = 12.sp)
            }
        }
    }
}
