package com.abm.erp.data

import android.content.Context
import com.abm.erp.data.room.AppDatabase
import com.abm.erp.data.room.BoardroomQueryEntity
import com.abm.erp.data.room.Converters
import com.abm.erp.data.room.DealerEntity
import com.abm.erp.data.room.EngagementCampaignEntity
import com.abm.erp.data.room.FieldEmployeeRouteEntity
import com.abm.erp.data.room.PaymentProofEntity
import com.abm.erp.data.room.PayrollLineEntity
import com.abm.erp.data.room.ProductionBatchEntity
import com.abm.erp.data.room.RawMaterialLotEntity
import com.abm.erp.data.room.RetailOrderEntity
import com.abm.erp.data.room.VoiceInvoiceEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneOffset

/**
 * Single source of truth for the whole app, now backed by a real on-device
 * Room database instead of an in-memory list. The public API (every val and
 * fun below) is intentionally identical to the original in-memory version,
 * so no UI Composable needs to change: only what's *inside* these functions
 * changed, from list mutation to real DB reads/writes.
 *
 * Call MockRepository.init(context) once, from ABMApplication.onCreate,
 * before any Composable reads from it.
 */
object MockRepository {

    private lateinit var db: AppDatabase
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun init(context: Context) {
        if (::db.isInitialized) return
        db = AppDatabase.getInstance(context)
        seedIfEmpty()
        wireFlows()
    }

    // ---- Company / users (kept simple/in-memory: rarely change, not core business data) ----
    val companies = listOf(Company("C-1", "ABM Corporation"))
    private val _activeCompanyId = MutableStateFlow(companies.first().id)
    val activeCompanyId: StateFlow<String> = _activeCompanyId.asStateFlow()
    fun switchCompany(id: String) = _activeCompanyId.update { id }

    // ---- Session / login ----
    // Small demo directory matching the design prototype's PIN accounts, so this first
    // Kotlin pass behaves identically to what's already been validated in the JSX design.
    // A real login later replaces this map with a backend call + secure on-device session.
    // Mutable (StateFlow, not a plain val) because Chairman can reset anyone's PIN from the
    // Account & Access Control screen — the old PIN must stop working immediately.
    private val _demoAccounts = MutableStateFlow(
        mapOf(
            "12345" to AppUser("U-CHAIR", "Zahid Hossain", UserRole.CHAIRMAN, "C-1", "All Bangladesh · Board", "CHAIR-1"),
            "11111" to AppUser("U-SR-BARISHAL", "Rafiq Hasan", UserRole.SR, "C-1", "Barishal district ▸ Notun Bazar", "SR-Barishal"),
            "22222" to AppUser("U-RSM-KHULNA", "Kabir Ahmed", UserRole.RSM, "C-1", "Khulna division (all districts)", "RSM-Khulna"),
            "33333" to AppUser("U-ASM-RANGPUR", "Mahmudul Islam", UserRole.ASM, "C-1", "Rangpur district", "ASM-Rangpur"),
        )
    )
    val demoAccountsFlow: StateFlow<Map<String, AppUser>> = _demoAccounts.asStateFlow()
    val demoAccounts: Map<String, AppUser> get() = _demoAccounts.value

    /** Chairman-only: invalidates oldPin, returns a fresh random 5-digit PIN for the same person. */
    fun resetPin(oldPin: String): String {
        val newPin = (10000..99999).random().toString()
        _demoAccounts.update { current ->
            val user = current[oldPin] ?: return@update current
            (current - oldPin) + (newPin to user)
        }
        return newPin
    }

    // ---- Device lockout: 3 wrong PIN attempts locks this device until the
    // Chairman's own PIN unlocks it (either on the lock screen itself, or
    // from the Account & Access Control screen once someone IS logged in). ----
    private val _deviceLocked = MutableStateFlow(false)
    val deviceLocked: StateFlow<Boolean> = _deviceLocked.asStateFlow()
    private val _failedAttempts = MutableStateFlow(0)
    val failedAttempts: StateFlow<Int> = _failedAttempts.asStateFlow()

    fun recordFailedPinAttempt() {
        _failedAttempts.update { it + 1 }
        if (_failedAttempts.value >= 3) _deviceLocked.value = true
    }

    fun unlockDevice() {
        _deviceLocked.value = false
        _failedAttempts.value = 0
    }

    /** True only for the literal Chairman PIN "12345" account — used to gate the unlock pad. */
    fun isChairmanPin(code: String): Boolean = demoAccounts[code]?.role == UserRole.CHAIRMAN

    private val _currentUser = MutableStateFlow(demoAccounts.getValue("12345"))
    val currentUserFlow: StateFlow<AppUser> = _currentUser.asStateFlow()
    val currentUser: AppUser get() = _currentUser.value

    /** Called by LoginScreen once a PIN or biometric prompt succeeds. */
    fun completeLogin(user: AppUser) {
        _currentUser.value = user
    }

    // ---- Per-employee vacancy (not per-tier): which specific people in
    // EMPLOYEE_DIRECTORY are currently marked vacant. Chairman-only control,
    // exposed on the Vacant Positions screen. Now backed by Firestore via
    // FirebaseSync, so a toggle on the Chairman's phone reaches every other
    // device — that's the whole point, a local-only list can't do that.
    // Falls back to a local-only Set if Firebase isn't configured yet. ----
    val vacantEmployeeIds: StateFlow<Set<String>> get() = FirebaseSync.vacantEmployeeIds
    fun toggleVacant(employeeId: String) = FirebaseSync.toggleVacant(employeeId)

    // ---- Sales chain ----
    lateinit var orders: StateFlow<List<RetailOrder>>
        private set

    fun advanceOrder(id: String, next: OrderStage, dealerId: String? = null) {
        scope.launch { db.retailOrderDao().advance(id, next.name, dealerId) }
    }

    fun logNewOrder(
        retailerName: String, items: String, amount: Double, zone: String,
        photoUri: String? = null, lat: Double? = null, lng: Double? = null,
    ) {
        scope.launch {
            val nextNum = 100 + db.retailOrderDao().count() + 1
            db.retailOrderDao().upsert(
                RetailOrderEntity(
                    id = "ORD-$nextNum",
                    retailerName = retailerName,
                    loggedBySoId = currentUser.id,
                    zone = zone,
                    items = items,
                    amount = amount,
                    stage = OrderStage.SO_LOGGED.name,
                    routedDealerId = null,
                    loggedAtEpochMillis = System.currentTimeMillis(),
                    retailerPhotoUri = photoUri,
                    retailerLat = lat,
                    retailerLng = lng,
                    retailerQrCode = com.abm.erp.util.QrCodeGenerator.retailerCode(retailerName, zone),
                )
            )
        }
    }

    lateinit var dealers: StateFlow<List<Dealer>>
        private set

    fun riskBand(dealer: Dealer): RiskBand {
        val ratio = if (dealer.salesLast90Days == 0.0) 1.0 else dealer.dueBalance / dealer.salesLast90Days
        return when {
            ratio < 0.3 -> RiskBand.GREEN
            ratio < 0.6 -> RiskBand.YELLOW
            else -> RiskBand.RED
        }
    }

    fun isOrderLocked(dealerId: String): Boolean =
        dealers.value.find { it.id == dealerId }?.let { riskBand(it) == RiskBand.RED } ?: false

    // ---- Geotagged CRM ----
    lateinit var routes: StateFlow<List<FieldEmployeeRoute>>
        private set

    lateinit var campaigns: StateFlow<List<EngagementCampaign>>
        private set

    fun broadcastCampaign(channel: CampaignChannel, message: String, zone: String) {
        scope.launch {
            db.engagementCampaignDao().upsert(
                EngagementCampaignEntity(
                    id = "CMP-${System.currentTimeMillis()}",
                    channel = channel.name,
                    message = message,
                    targetZone = zone,
                    sentCount = (40..200).random(),
                )
            )
        }
    }

    /** Appends one real GPS fix to the employee's route for today. Called every ~15s while live tracking is on. */
    fun recordGpsPing(employeeId: String, employeeName: String, lat: Double, lng: Double, spoofed: Boolean) {
        scope.launch {
            val today = LocalDate.now().toEpochDay()
            val existing = db.fieldEmployeeRouteDao().getForEmployeeAndDate(employeeId, today)
            val existingBreadcrumbs = existing?.let { Converters.unpackBreadcrumbs(it.breadcrumbsRaw) } ?: emptyList()
            val updated = existingBreadcrumbs + GpsPing(lat, lng, LocalDateTime.now(), spoofed)
            db.fieldEmployeeRouteDao().upsertAll(
                listOf(
                    FieldEmployeeRouteEntity(
                        employeeId = employeeId,
                        employeeName = employeeName,
                        dateEpochDay = today,
                        breadcrumbsRaw = Converters.packBreadcrumbs(updated),
                    )
                )
            )
        }
    }

    // ---- HRM & Payroll ----
    lateinit var payroll: StateFlow<List<PayrollLine>>
        private set

    // ---- Credit / billing / payments ----
    lateinit var invoices: StateFlow<List<VoiceInvoice>>
        private set

    fun updateInvoiceItem(invoiceId: String, index: Int, item: InvoiceLineItem) {
        scope.launch {
            val current = invoices.value.find { it.id == invoiceId } ?: return@launch
            val items = current.items.toMutableList().also { it[index] = item }
            db.voiceInvoiceDao().update(
                VoiceInvoiceEntity(
                    id = current.id,
                    dealerId = current.dealerId,
                    itemsRaw = Converters.packInvoiceItems(items),
                    previousDue = current.previousDue,
                )
            )
        }
    }

    lateinit var payments: StateFlow<List<PaymentProof>>
        private set

    fun setPaymentStatus(id: String, status: PaymentVerificationStatus) {
        scope.launch { db.paymentProofDao().setStatus(id, status.name) }
    }

    // ---- Production ----
    lateinit var lots: StateFlow<List<RawMaterialLot>>
        private set

    fun movingAverageCost(material: String): Double {
        val matching = lots.value.filter { it.materialName == material }
        val totalQty = matching.sumOf { it.qtyKg }
        return if (totalQty == 0.0) 0.0 else matching.sumOf { it.qtyKg * it.costPerKg } / totalQty
    }

    lateinit var batches: StateFlow<List<ProductionBatch>>
        private set

    fun receiveGatepass(batchId: String) {
        scope.launch { db.productionBatchDao().receiveGatepass(batchId) }
    }

    // ---- BI / advisory ----
    lateinit var prescriptions: List<PrescriptionCard>
        private set

    lateinit var boardroomHistory: StateFlow<List<BoardroomQuery>>
        private set

    // ---- Task Manager ----
    lateinit var tasks: StateFlow<List<TaskItem>>
        private set

    fun addTask(title: String, assignee: String) {
        scope.launch {
            db.taskDao().upsert(TaskItemEntity(id = "TASK-${System.currentTimeMillis()}", title = title, assignee = assignee, done = false, createdAtEpochMillis = System.currentTimeMillis()))
        }
    }

    fun setTaskDone(id: String, done: Boolean) {
        scope.launch { db.taskDao().setDone(id, done) }
    }

    // ---- Approvals ----
    lateinit var approvals: StateFlow<List<ApprovalRequest>>
        private set

    fun requestApproval(type: ApprovalType, fromEmployee: String, detail: String) {
        scope.launch {
            db.approvalDao().upsert(
                ApprovalRequestEntity(
                    id = "APR-${System.currentTimeMillis()}", type = type.name, fromEmployee = fromEmployee,
                    detail = detail, status = ApprovalStatus.PENDING.name, createdAtEpochMillis = System.currentTimeMillis(),
                )
            )
        }
    }

    fun setApprovalStatus(id: String, status: ApprovalStatus) {
        scope.launch { db.approvalDao().setStatus(id, status.name) }
    }

    // ---- Courier & Logistics ----
    lateinit var couriers: StateFlow<List<CourierPartner>>
        private set

    lateinit var shipments: StateFlow<List<Shipment>>
        private set

    fun bookShipment(courierId: String, dealerOrRetailer: String) {
        scope.launch {
            val hasApi = couriers.value.firstOrNull { it.id == courierId }?.hasApi ?: false
            val trackingId = if (hasApi) "${courierId.take(2).uppercase()}-${(10000..99999).random()}" else null
            db.shipmentDao().upsert(
                ShipmentEntity(
                    id = "SHP-${System.currentTimeMillis()}", courierId = courierId, dealerOrRetailer = dealerOrRetailer,
                    trackingId = trackingId, status = ShipmentStatus.PICKED_UP.name,
                )
            )
        }
    }

    private val autoAdvanceStages = listOf(ShipmentStatus.PICKED_UP, ShipmentStatus.IN_TRANSIT, ShipmentStatus.OUT_FOR_DELIVERY, ShipmentStatus.DELIVERED)

    /** For API-connected couriers: simulate pulling the next tracking stage. Manual couriers use setShipmentStatus directly instead. */
    fun refreshShipmentStatus(shipmentId: String) {
        scope.launch {
            val current = shipments.value.firstOrNull { it.id == shipmentId } ?: return@launch
            val idx = autoAdvanceStages.indexOf(current.status)
            val next = autoAdvanceStages.getOrElse(idx + 1) { current.status }
            db.shipmentDao().setStatus(shipmentId, next.name)
        }
    }

    fun setShipmentStatus(shipmentId: String, status: ShipmentStatus) {
        scope.launch { db.shipmentDao().setStatus(shipmentId, status.name) }
    }

    /** Simulated Gemini BI response: pattern-matches the question against live data. Replace with a real Gemini function-calling call server-side. */
    fun askBoardroom(question: String): String {
        val q = question.lowercase()
        val answer = when {
            "profit" in q || "margin" in q ->
                "Barisal zone margin is down mainly due to dealer discounts averaging 9.2% against a 6% target, combined with a 14% rise in raw leaf cost this month."
            "boost" in q || "best" in q || "zone" in q ->
                "ABM Masala Tea is growing fastest in Khulna zone (+18% vs forecast); recommend reallocating stock there and running a robocall promo."
            "absence" in q || "attendance" in q ->
                "3 field officers have unapproved GPS gaps this week, concentrated in Barisal zone during afternoon shifts."
            else ->
                "Based on current production, credit-risk, and attendance data, no critical anomalies outside the flagged prescription cards below."
        }
        scope.launch {
            db.boardroomQueryDao().insert(
                BoardroomQueryEntity(question = question, answer = answer, askedAtEpochMillis = System.currentTimeMillis())
            )
        }
        return answer
    }

    // ================= internal wiring =================

    private fun wireFlows() {
        orders = db.retailOrderDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        dealers = db.dealerDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        routes = db.fieldEmployeeRouteDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        campaigns = db.engagementCampaignDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        payroll = db.payrollDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        invoices = db.voiceInvoiceDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        payments = db.paymentProofDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        lots = db.rawMaterialLotDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        batches = db.productionBatchDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        prescriptions = listOf(
            PrescriptionCard("P-1", "Barisal margin drop", "Discount stacking on Masala Tea is eroding margin 4pp week-over-week. Recommend capping dealer discount at 6% until due balances clear.", RiskBand.RED),
            PrescriptionCard("P-2", "Khulna momentum", "ABM Masala Tea is outselling forecast by 18% in Khulna. Recommend shifting 200kg of buffer stock from Rajshahi warehouse.", RiskBand.GREEN),
            PrescriptionCard("P-3", "Attendance gap", "3 field officers show repeated GPS gaps during duty hours this week. Recommend a manual route audit before payroll close.", RiskBand.YELLOW),
        )

        boardroomHistory = db.boardroomQueryDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        tasks = db.taskDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        approvals = db.approvalDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        couriers = db.courierDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        shipments = db.shipmentDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
    }

    /** Inserts the same starter data the old in-memory version shipped with, but only once, on first run (empty DB). */
    private fun seedIfEmpty() = runBlocking(Dispatchers.IO) {
        if (db.retailOrderDao().count() == 0) {
            db.retailOrderDao().upsertAll(
                listOf(
                    RetailOrder("ORD-101", "Green Valley Store", "SO-1", "Barisal", "ABM Masala Tea x40 ctn", 48000.0).toEntity(),
                    RetailOrder("ORD-102", "City Corner Shop", "SO-2", "Khulna", "ABM Tea Classic x25 ctn", 31250.0, stage = OrderStage.ASM_VERIFIED).toEntity(),
                    RetailOrder("ORD-103", "New Bazar Traders", "SO-1", "Barisal", "ABM Masala Tea x60 ctn", 72000.0, stage = OrderStage.DEALER_ROUTED, routedDealerId = "D-1").toEntity(),
                )
            )
        }
        if (db.dealerDao().count() == 0) {
            db.dealerDao().upsertAll(
                listOf(
                    DealerEntity("D-1", "Barisal Central Dealer", "Barisal", 185000.0, 620000.0),
                    DealerEntity("D-2", "Khulna Wholesale Hub", "Khulna", 42000.0, 410000.0),
                    DealerEntity("D-3", "Rajshahi Distributors", "Rajshahi", 305000.0, 260000.0),
                )
            )
        }
        if (db.fieldEmployeeRouteDao().count() == 0) {
            val breadcrumbs = listOf(
                GpsPing(22.701, 90.353, LocalDateTime.now().minusHours(4)),
                GpsPing(22.706, 90.360, LocalDateTime.now().minusHours(3)),
                GpsPing(22.712, 90.368, LocalDateTime.now().minusHours(1)),
            )
            db.fieldEmployeeRouteDao().upsertAll(
                listOf(
                    FieldEmployeeRouteEntity(
                        employeeId = "SO-1",
                        employeeName = "Sales Officer Rafiq",
                        dateEpochDay = LocalDate.now().toEpochDay(),
                        breadcrumbsRaw = Converters.packBreadcrumbs(breadcrumbs),
                    )
                )
            )
        }
        if (db.payrollDao().count() == 0) {
            db.payrollDao().upsertAll(
                listOf(
                    PayrollLineEntity("SO-1", "Sales Officer Rafiq", 22000.0, 500000.0, 460000.0, 0.015, 1, 733.0),
                    PayrollLineEntity("SO-2", "Sales Officer Nadia", 22000.0, 500000.0, 610000.0, 0.015, 0, 733.0),
                    PayrollLineEntity("ASM-1", "Area Manager Kabir", 38000.0, 1500000.0, 1290000.0, 0.01, 2, 1266.0),
                )
            )
        }
        if (db.voiceInvoiceDao().count() == 0) {
            db.voiceInvoiceDao().upsertAll(
                listOf(
                    VoiceInvoiceEntity(
                        id = "INV-VB-01",
                        dealerId = "D-1",
                        itemsRaw = Converters.packInvoiceItems(listOf(InvoiceLineItem("ABM Masala Tea 1kg", 50.0, "kg", 420.0, 5.0))),
                        previousDue = 185000.0,
                    )
                )
            )
        }
        if (db.paymentProofDao().count() == 0) {
            db.paymentProofDao().upsertAll(listOf(PaymentProofEntity("PMT-1", "D-2", 60000.0, "TXN-88213-BKASH", PaymentVerificationStatus.PENDING_VERIFICATION.name)))
        }
        if (db.rawMaterialLotDao().count() == 0) {
            db.rawMaterialLotDao().upsertAll(
                listOf(
                    RawMaterialLotEntity("RM-1", "Raw Leaves", 500.0, 210.0, LocalDate.now().minusDays(3).toEpochDay()),
                    RawMaterialLotEntity("RM-2", "Raw Leaves", 300.0, 225.0, LocalDate.now().minusDays(1).toEpochDay()),
                    RawMaterialLotEntity("RM-3", "CMC Thickener", 80.0, 340.0, LocalDate.now().minusDays(2).toEpochDay()),
                )
            )
        }
        if (db.productionBatchDao().count() == 0) {
            db.productionBatchDao().upsertAll(
                listOf(
                    ProductionBatchEntity("BATCH-77", "Spray Dryer 30kg", 30.0, 24.5, false),
                    ProductionBatchEntity("BATCH-78", "Drum Dryer 30kg", 30.0, 26.1, true),
                )
            )
        }
        if (db.courierDao().count() == 0) {
            db.courierDao().upsertAll(
                listOf(
                    CourierPartnerEntity("CR-1", "Pathao Courier", true),
                    CourierPartnerEntity("CR-2", "Sundarban Courier", true),
                    CourierPartnerEntity("CR-3", "Local Van Service", false),
                )
            )
        }
        if (db.approvalDao().count() == 0) {
            db.approvalDao().upsert(
                ApprovalRequestEntity(
                    id = "APR-1", type = ApprovalType.DISCOUNT.name, fromEmployee = "SR — Rafiq Hasan",
                    detail = "8% discount for New Bazar Traders (target: 6%)", status = ApprovalStatus.PENDING.name,
                    createdAtEpochMillis = System.currentTimeMillis(),
                )
            )
        }
    }
}

// ================= Entity <-> domain mappers =================

private fun RetailOrder.toEntity() = RetailOrderEntity(
    id = id, retailerName = retailerName, loggedBySoId = loggedBySoId, zone = zone, items = items,
    amount = amount, stage = stage.name, routedDealerId = routedDealerId,
    loggedAtEpochMillis = loggedAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    retailerPhotoUri = retailerPhotoUri, retailerLat = retailerLat, retailerLng = retailerLng, retailerQrCode = retailerQrCode,
)

private fun RetailOrderEntity.toDomain() = RetailOrder(
    id = id, retailerName = retailerName, loggedBySoId = loggedBySoId, zone = zone, items = items,
    amount = amount, stage = OrderStage.valueOf(stage), routedDealerId = routedDealerId,
    loggedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(loggedAtEpochMillis), ZoneOffset.UTC),
    retailerPhotoUri = retailerPhotoUri, retailerLat = retailerLat, retailerLng = retailerLng, retailerQrCode = retailerQrCode,
)

private fun DealerEntity.toDomain() = Dealer(id = id, name = name, zone = zone, dueBalance = dueBalance, salesLast90Days = salesLast90Days)

private fun FieldEmployeeRouteEntity.toDomain() = FieldEmployeeRoute(
    employeeId = employeeId, employeeName = employeeName,
    date = LocalDate.ofEpochDay(dateEpochDay),
    breadcrumbs = Converters.unpackBreadcrumbs(breadcrumbsRaw),
)

private fun EngagementCampaignEntity.toDomain() = EngagementCampaign(
    id = id, channel = CampaignChannel.valueOf(channel), message = message, targetZone = targetZone, sentCount = sentCount,
)

private fun PayrollLineEntity.toDomain() = PayrollLine(
    employeeId = employeeId, employeeName = employeeName, basePay = basePay, targetAmount = targetAmount,
    achievedAmount = achievedAmount, commissionRate = commissionRate, unapprovedAbsenceDays = unapprovedAbsenceDays,
    dailyWage = dailyWage,
)

private fun VoiceInvoiceEntity.toDomain() = VoiceInvoice(
    id = id, dealerId = dealerId, items = Converters.unpackInvoiceItems(itemsRaw), previousDue = previousDue,
)

private fun PaymentProofEntity.toDomain() = PaymentProof(
    id = id, dealerId = dealerId, amount = amount, proofRef = proofRef,
    status = PaymentVerificationStatus.valueOf(status),
)

private fun RawMaterialLotEntity.toDomain() = RawMaterialLot(
    id = id, materialName = materialName, qtyKg = qtyKg, costPerKg = costPerKg,
    purchasedOn = LocalDate.ofEpochDay(purchasedOnEpochDay),
)

private fun ProductionBatchEntity.toDomain() = ProductionBatch(
    id = id, cycleType = cycleType, inputKg = inputKg, outputKg = outputKg, gatepassReceived = gatepassReceived,
)

private fun BoardroomQueryEntity.toDomain() = BoardroomQuery(
    question = question, answer = answer,
    askedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(askedAtEpochMillis), ZoneOffset.UTC),
)

private fun TaskItemEntity.toDomain() = TaskItem(
    id = id, title = title, assignee = assignee, done = done,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
)

private fun ApprovalRequestEntity.toDomain() = ApprovalRequest(
    id = id, type = ApprovalType.valueOf(type), fromEmployee = fromEmployee, detail = detail,
    status = ApprovalStatus.valueOf(status),
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
)

private fun CourierPartnerEntity.toDomain() = CourierPartner(id = id, name = name, hasApi = hasApi)

private fun ShipmentEntity.toDomain() = Shipment(
    id = id, courierId = courierId, dealerOrRetailer = dealerOrRetailer, trackingId = trackingId,
    status = ShipmentStatus.valueOf(status),
)
