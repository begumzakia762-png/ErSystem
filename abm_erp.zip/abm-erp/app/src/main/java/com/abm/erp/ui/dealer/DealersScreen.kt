package com.abm.erp.ui.dealer

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.FirebaseSync
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

@Composable
fun DealersScreen() {
    val dealers by MockRepository.dealers.collectAsState()
    val allOrders by FirebaseSync.dealerOrders.collectAsState()
    val pending = allOrders.filter { it.status == "Pending" }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Dealers & Stock", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))

        if (pending.isNotEmpty()) {
            Text("Pending dealer orders (${pending.size})", style = MaterialTheme.typography.titleMedium, color = WarningAmber)
            Spacer(Modifier.height(8.dp))
            pending.forEach { o ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text(o.dealerName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Text("${o.product} × ${o.qty}", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { FirebaseSync.setDealerOrderStatus(o.id, "Approved") }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) {
                            Text("Approve")
                        }
                        OutlinedButton(onClick = { FirebaseSync.setDealerOrderStatus(o.id, "Rejected") }) {
                            Text("Reject", color = DangerRed)
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        Text("Dealers in your territory", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(dealers, key = { it.id }) { d ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text(d.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Text(d.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Spacer(Modifier.height(4.dp))
                    Text("Due: ৳${"%,.0f".format(d.dueBalance)} · 90-day sales: ৳${"%,.0f".format(d.salesLast90Days)}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
