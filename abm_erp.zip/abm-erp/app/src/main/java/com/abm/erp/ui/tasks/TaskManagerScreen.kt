package com.abm.erp.ui.tasks

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary

@Composable
fun TaskManagerScreen() {
    val tasks by MockRepository.tasks.collectAsState()
    var title by remember { mutableStateOf("") }
    var assignee by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Task Manager", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Task title") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = assignee, onValueChange = { assignee = it }, label = { Text("Assign to (e.g. SR — Rafiq)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    if (title.isBlank()) return@Button
                    MockRepository.addTask(title, assignee.ifBlank { "Unassigned" })
                    title = ""; assignee = ""
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Add task") }
        }
        Spacer(Modifier.height(16.dp))
        if (tasks.isEmpty()) {
            Text("No tasks yet.", color = TextSecondary)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(tasks, key = { it.id }) { task ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Checkbox(checked = task.done, onCheckedChange = { MockRepository.setTaskDone(task.id, it) })
                        Column {
                            Text(
                                task.title,
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold,
                                textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None,
                            )
                            Text(task.assignee, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                    }
                }
            }
        }
    }
}
