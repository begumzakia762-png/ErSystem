package com.abm.erp.ui.production

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.*

@Composable
fun ProductionScreen() {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Factory Production Wing", style = MaterialTheme.typography.headlineSmall)
        Text("Isolated from marketing operations", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        TabRow(selectedTabIndex = tab, containerColor = Color.Transparent, contentColor = ElectricCyan) {
            listOf("Materials", "Batches", "Factory HRM").forEachIndexed { i, label ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(label) })
            }
        }
        Spacer(Modifier.height(12.dp))
        when (tab) {
            0 -> MaterialsTab()
            1 -> BatchesTab()
            else -> FactoryHrmTab()
        }
    }
}

@Composable
private fun MaterialsTab() {
    val lots by MockRepository.lots.collectAsState()
    val materials = lots.map { it.materialName }.distinct()

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Moving average cost", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                materials.forEach { m ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(m, style = MaterialTheme.typography.bodyLarge)
                        Text("৳${"%.2f".format(MockRepository.movingAverageCost(m))}/kg", color = ElectricCyan, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        item { Text("Purchase lots", style = MaterialTheme.typography.titleMedium) }
        items(lots) { lot ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("${lot.materialName} — ${lot.qtyKg}kg", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text("Cost ৳${lot.costPerKg}/kg · purchased ${lot.purchasedOn}", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun BatchesTab() {
    val batches by MockRepository.batches.collectAsState()
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(batches) { b ->
            val yieldPct = (b.outputKg / b.inputKg) * 100
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("${b.id} · ${b.cycleType}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text("Input ${b.inputKg}kg → Output ${b.outputKg}kg  (${"%.1f".format(yieldPct)}% yield)", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                if (b.gatepassReceived) {
                    Text("✓ Gatepass received by Central Warehouse Incharge", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
                } else {
                    Button(onClick = { MockRepository.receiveGatepass(b.id) }, colors = ButtonDefaults.buttonColors(containerColor = DeepIndigo)) {
                        Text("Tap \"Receive\" — release from production")
                    }
                }
            }
        }
    }
}

@Composable
private fun FactoryHrmTab() {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Factory attendance lock", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            "Laborer check-in is only accepted when both are true: device is on the factory WiFi IP allowlist, and GPS falls inside the factory geofence polygon. Either failing marks the day as unapproved for payroll purposes.",
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(12.dp))
        listOf(
            Triple("Laborer 12", true, true),
            Triple("Laborer 27", true, false),
            Triple("Laborer 33", false, true),
        ).forEach { (name, wifi, geo) ->
            val ok = wifi && geo
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(name, style = MaterialTheme.typography.bodyLarge)
                Text(
                    if (ok) "✓ Valid check-in" else "✗ Flagged (wifi=$wifi, geofence=$geo)",
                    color = if (ok) SuccessGreen else DangerRed,
                    style = MaterialTheme.typography.labelSmall,
                )
            }
        }
    }
}
