package com.abm.erp.ui.hrm

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.MockRepository
import com.abm.erp.data.PayrollLine
import com.abm.erp.theme.*

@Composable
fun PayrollScreen() {
    val payroll by MockRepository.payroll.collectAsState()
    var expandedId by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("HRM & Payroll", style = MaterialTheme.typography.headlineSmall)
            Text("Dynamic 3-layer payroll: base pay × achievement curve + commission − absence penalty", style = MaterialTheme.typography.bodyMedium)
        }
        items(payroll) { line ->
            PayrollCard(line, expanded = expandedId == line.employeeId, onToggle = {
                expandedId = if (expandedId == line.employeeId) null else line.employeeId
            })
        }
    }
}

@Composable
private fun PayrollCard(line: PayrollLine, expanded: Boolean, onToggle: () -> Unit) {
    val band = when {
        line.achievementPct >= 100 -> SuccessGreen
        line.achievementPct >= 80 -> WarningAmber
        else -> DangerRed
    }
    GlassCard(modifier = Modifier.fillMaxWidth().clickable(onClick = onToggle)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(line.employeeName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text("Achievement: ${"%.1f".format(line.achievementPct)}%", color = band, style = MaterialTheme.typography.labelSmall)
            }
            Text("৳${"%,.0f".format(line.netPayable)}", style = MaterialTheme.typography.titleMedium, color = ElectricCyan)
        }
        if (expanded) {
            Spacer(Modifier.height(10.dp))
            Divider(color = GlassBorder)
            Spacer(Modifier.height(10.dp))
            StatRow("Base pay", line.basePay)
            StatRow("Scaling factor", null, "${"%.2f".format(line.scalingFactor)}×")
            StatRow("Base × scaling", line.basePay * line.scalingFactor)
            StatRow("Sales commission (${"%.1f".format(line.commissionRate * 100)}%)", line.commission)
            StatRow("Unapproved absences", null, "${line.unapprovedAbsenceDays} day(s) — GPS-verified")
            StatRow("Absence penalty", -line.absencePenalty)
            Spacer(Modifier.height(6.dp))
            Divider(color = GlassBorder)
            Spacer(Modifier.height(6.dp))
            StatRow("Net payable", line.netPayable, bold = true)
            Spacer(Modifier.height(8.dp))
            Text(
                "Dispute-proof statement generated · penalty derived from missing/spoofed GPS nodes during duty hours, not manual entry.",
                style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}

@Composable
private fun StatRow(label: String, amount: Double?, override: String? = null, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(
            override ?: "৳${"%,.0f".format(amount ?: 0.0)}",
            color = if (bold) ElectricCyan else TextPrimary,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

