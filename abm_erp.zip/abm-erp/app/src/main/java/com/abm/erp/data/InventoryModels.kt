package com.abm.erp.data

import java.time.LocalDateTime

// ---------- Inventory / Stock Management ----------

data class Product(
    val id: String,
    val sku: String,
    val name: String,
    val unit: String,
    val category: String,
    val reorderThreshold: Double,
    val defaultUnitPrice: Double,
)

data class Warehouse(val id: String, val name: String, val zone: String, val stockCategory: StockCategory = StockCategory.STORE)

enum class MovementType { IN, OUT, ADJUST }

/** A denormalized, UI-ready view: one row per product+warehouse with names already resolved. */
data class StockLevelView(
    val productId: String,
    val productName: String,
    val unit: String,
    val warehouseId: String,
    val warehouseName: String,
    val quantityOnHand: Double,
    val reorderThreshold: Double,
    val stockCategory: StockCategory = StockCategory.STORE,
) {
    val isLowStock: Boolean get() = quantityOnHand <= reorderThreshold
}

data class StockMovement(
    val id: Long,
    val productId: String,
    val productName: String,
    val warehouseId: String,
    val warehouseName: String,
    val type: MovementType,
    val quantity: Double,
    val reason: String,
    val timestamp: LocalDateTime,
)
