# প্রজেক্টের নিয়ম ও বর্তমান অবস্থা (PROJECT_NOTES.md)

এই ফাইলটা প্রজেক্টের সাথেই থাকে — নতুন চ্যাট শুরু করলেও এই ফাইলটা Claude-কে
দেখালে (বা এই ফোল্ডার আপলোড করলে) ও সাথে সাথে পুরো নিয়ম আর এখন পর্যন্ত কী
হয়েছে বুঝে যাবে।

## কাজের নিয়ম (workflow) — এটাই সবচেয়ে জরুরি
1. যেকোনো **নতুন মডিউল/ফিচার/মডিফিকেশন** → প্রথমে **JSX প্রোটোটাইপে** বানাতে
   হবে (দ্রুত visual দেখে ঠিক করার জন্য, ক্লিক করলেই preview হয়)।
2. ব্যবহারকারী (মালিক) JSX দেখে approve করলে, **তারপরই** সেটা **Kotlin/
   Jetpack Compose**-এ কনভার্ট হবে।
3. কখনো সরাসরি Kotlin-এ নতুন/অপ্রমাণিত ফিচার বানানো হবে না — JSX ধাপ বাদ
   দেওয়া যাবে না।
4. প্রতিবার Kotlin প্রজেক্ট দেওয়ার সময় **পুরো প্রজেক্ট নতুন করে zip** করে
   দেওয়া হয় (আলাদা টুকরো/প্যাচ না) — ব্যবহারকারী পুরনো ফোল্ডার মুছে নতুন
   zip extract করে Android Studio-তে খোলেন।
5. ব্যবহারকারী কোনো কোডিং জানেন না এবং শিখতেও চান না — শুধু copy-paste +
   Sync + Run করবেন। তাই প্রতিটা ডেলিভারি নিজে থেকেই সম্পূর্ণ/build-যোগ্য
   হতে হবে, আর কোনো ম্যানুয়াল কোড-এডিট করতে বলা যাবে না।
6. Error এলে ব্যবহারকারী শুধু error message কপি করে পাঠাবেন — Claude সেটা
   দেখে ঠিক করে নতুন zip দেবে।

## Firebase (সেটআপ হয়ে গেছে)
- প্রজেক্ট: **abm-corporation** (project_number 114190194137)
- `app/google-services.json` এ আসল কনফিগ বসানো আছে — এটা প্রতিটা zip-এ
  এমনিতেই থাকবে, নতুন করে বসাতে হবে না
- Firestore + Anonymous Authentication চালু করা আছে ব্যবহারকারীর কনসোলে
- Security rules: `firestore.rules` ফাইলে আছে (ইতিমধ্যে console-এ paste করা)
- এখন যা Firestore দিয়ে সিঙ্ক হয়: **Complaint Box**, **Vacant Positions**
- বাকি সব (Sales/Inventory/Billing/ইত্যাদি) এখনো local Room DB-তে —
  ধাপে ধাপে Firestore-এ সরানো হবে

## হার্ডওয়্যার/GPS/permission নিয়ে standard (গুরুত্বপূর্ণ)
প্রতিটা `uses-permission` এর সাথে অবশ্যই বাস্তব, properly-guarded runtime
request + কার্যকরী ফিচার থাকতে হবে — permission declare করে রাখা কিন্তু
আসল runtime request/foreground service না থাকা মানেই ভবিষ্যতে ঠিক GPS/
biometric-এর মতো bug। শেষ অডিটে এই কারণেই `ACCESS_BACKGROUND_LOCATION`
আর `RECORD_AUDIO` সরানো হয়েছিল (declared ছিল কিন্তু কোনো কোড actually
ব্যবহার করছিল না)। নতুন কোনো হার্ডওয়্যার ফিচার (camera, microphone, ইত্যাদি)
যোগ করার সময় permission + runtime request + ফিচার — তিনটাই একসাথে, একই
commit-এ যোগ করতে হবে।

## এখন পর্যন্ত Kotlin-এ যা পোর্ট হয়েছে (real APK-তে কাজ করে)
- Login (PIN + Fingerprint/Face, gold-sky থিম)
- Device lockout (৩ বার ভুল PIN → লক, শুধু Chairman-এর PIN দিয়ে আনলক)
- Forgot PIN → OTP flow (simulated, demo OTP: 0000)
- Dashboard (Employee Directory ২০৯ জন, ৬৪ জেলা, role-wise module grid,
  personal target/achievement, vacancy banner)
- Chairman's Notice (Firebase Storage image upload, সবাই দেখে)
- Vacant Positions (per-employee cascade)
- Account & Access Control (Chairman-only: PIN reset, device unlock)
- Complaint Box (Firestore-synced)
- Dealer Login + Order + ASM Approval (Firestore-synced — dealer এক ফোনে
  অর্ডার দেয়, ASM অন্য ফোনে approve করে)
- Sales Chain — এখন সহ ছবি/GPS ট্যাগ/real QR কোড (ZXing) retailer শপের জন্য
- Stock Management — Production vs Store category split
- Courier & Logistics (API + manual couriers)
- Task Manager, Approvals, Notifications (aggregated), Market Analysis
- CRM/GPS, Inventory, HR/Payroll, Billing, Production, AI Boardroom

## এখনো Kotlin-এ নেই (ভবিষ্যতে দরকার হতে পারে)
- Helpdesk module (dealer/retailer complaint ticketing — Complaint Box থেকে আলাদা)
- Reports module (এখন Market Analysis + প্রতিটা মডিউলের নিজস্ব ডেটা দিয়ে আংশিক কভার হয়)
- Accounts/Ledger module (NSM+ এর financial view)
- HR module-এ real employee directory sync (এখনো demo/generated data)

## Chain of command (ভুলে গেলে এটা দেখুন)
SR → TSM → ASM → RSM → DSM → NSM → AGM → GM → MD → **Chairman** (admin, সর্বোচ্চ)
